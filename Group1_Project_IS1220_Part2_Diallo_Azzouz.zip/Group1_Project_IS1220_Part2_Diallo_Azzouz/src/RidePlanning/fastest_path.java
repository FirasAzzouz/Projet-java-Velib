package RidePlanning;

import java.util.ArrayList;   
import mainClasses.*;
import otherClasses.*;
/**
 * 
 * @author Diallo
 *
 */
public class fastest_path implements RidePlanner {
	
	
	private int v1=4;
	private int v2=15;
	private int v3=20;
	private double t1;
	private double t2;
	private double t3;
	private double time;
	private BicycleType bicycleType;
	
	public fastest_path(BicycleType bicycleType) {
		super();
		this.bicycleType = bicycleType;
	}
	
	/**
	 * 
	 * 
	 * this method within the class fatest_path determines the fastest path between two points s and d.
	 * In order to do that , we use to loop to determine the couple stations that fulfill that condition.
	 * We have been given  the average walking speed (4km/h) and the average bicycle-riding speed which is 15km/h for mechanical bikes
	 * and 20km/h for electrical bikes
	 * 	 
	 * */
	@Override 
	public Station[] optimalStationsSearch(Point s, Point d, ArrayList<Station> stations) {
		Station [] optimalStations=new Station[2];
		
		time=Float.POSITIVE_INFINITY;
		
		
		for( Station st1: stations) {
			if (st1.getState()==StationState.ON_SERVICE && st1.getOccupiedSlots()>0) {
				for (Station st2:stations){
					if (st2.getState()==StationState.ON_SERVICE && st2.getFreeSlots()>0) {
						t1=Point.CalculateDistance(s,st1.getLocation())/v1;
						if (bicycleType==BicycleType.MECHANICAL) {
							t2=Point.CalculateDistance(st1.getLocation(),st2.getLocation())/v2;
						}
						
						else if (bicycleType==BicycleType.ELECTRICAL) {
							t2=Point.CalculateDistance(st1.getLocation(),st2.getLocation())/v3;
						}
						t3=Point.CalculateDistance(d,st2.getLocation())/v1;
						if (t1+t2+t3<time) {
							time= t1+t2+t3;
							optimalStations[0]=st1;
							//optimalStations[1]=st2;
						}
					}
				}
			}
		}
		optimalStations[1]=Point.ClosestStationDestinationPoint(d,stations);
		return optimalStations;
	}
}
