package RidePlanning;


import java.util.ArrayList;    
import mainClasses.*;
import otherClasses.*;
/**
 * 
 * @author Diallo
 *
 */
public interface RidePlanner {
	
	/**
	 * 
	 * 
	 * @param s: Point source of our user 
	 * @param d: Destination of the User 
	 * @param stations: List of station of our System My_velib
	 * @return
	 */
	public Station [] optimalStationsSearch(Point s, Point d, ArrayList<Station> stations);	
	

}