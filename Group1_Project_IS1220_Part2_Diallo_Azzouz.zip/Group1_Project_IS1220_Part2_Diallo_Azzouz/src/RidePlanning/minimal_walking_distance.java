package RidePlanning;

import java.util.ArrayList;    
import mainClasses.*;
import otherClasses.*;

/**
 * 
 * @author Diallo
 *
 */
public class minimal_walking_distance implements RidePlanner {
	
	private BicycleType bicycleType;
	
	
	
	public minimal_walking_distance(BicycleType bicycleType) {
		super();
		this.bicycleType = bicycleType;
	}



	/**
	 * 
	 * method that calculate the minimal walking distance 
	 * between a source(Point s) and a destination Point (point d)
	 * for doing so we determine the closest 
	 * stations from the source point and destination point .
	 * 
	 */
	
	
	public Station[] optimalStationsSearch(Point s, Point d, ArrayList<Station> stations) {
		
		Station [] optimalStations=new Station[2];
		
		optimalStations[0]=Point.ClosestStationSourcePoint(s,stations,bicycleType);
		optimalStations[1]=Point.ClosestStationDestinationPoint(d,stations);
		return optimalStations;
		
	}



	public BicycleType getBicycleType() {
		return bicycleType;
	}



	public void setBicycleType(BicycleType bicycleType) {
		this.bicycleType = bicycleType;
	}	
	
    
}
	
		
			
		


