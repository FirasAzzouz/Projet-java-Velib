package RidePlanning;

import java.util.ArrayList;  


import mainClasses.*;
import otherClasses.*;


/**
 * 
 * @author Diallo
 *
 */
public class prefer_plus_station implements RidePlanner{
	
	private BicycleType bicycleType;
	
	

	public prefer_plus_station(BicycleType bicycleType) {
		super();
		this.bicycleType = bicycleType;
	}


	private Station [] optimalStations=new Station[2];
	
	/**
	 * 
	 * this method return the plus station no further away than 10% 
	 * of the distance of the closest station to the destination 
	 * in case of any plus station has been found then we return the minimal walking distance station
	 * Also we use a method closestStationPlus(define below)  which determines all the station no further away than 10% of the
	 * distance of the closest station to the destination 
	 */
	
	@Override
	public Station[] optimalStationsSearch(Point s, Point d, ArrayList<Station> stations) {
		
		
		optimalStations[0]=Point.ClosestStationSourcePoint(s,stations,bicycleType);
		
		Station closestStation= Point.ClosestStationDestinationPoint(d,stations);
		Station closestStationPlus= ClosestStationPlus(d,stations);
		
		double distanceStation=Point.CalculateDistance(d, closestStation.getLocation());
		double distanceStationPlus=Point.CalculateDistance(d, closestStationPlus.getLocation());
		
		if (distanceStationPlus>1.1*distanceStation) {
			optimalStations[1]=closestStation;
		}
		else {
			optimalStations[1]=closestStationPlus;
		}
		
		return optimalStations;
		
	}
	
	
	/**
	 * Also we use a method closestStationPlus(define below)  which determines all the station no further away than 10% of the
	 * distance of the closest station to the destination
	 * 
	 * @param a
	 * @param s
	 * @return
	 */
	
    public Station ClosestStationPlus(Point a, ArrayList<Station> s){
		
		double distance = Float.POSITIVE_INFINITY ;
		Station st = s.get(0);

		for (Station sa : s) {
			if ((Point.CalculateDistance(sa.getLocation(),a)<distance)&&(sa instanceof StationPlus)&&(sa.getFreeSlots()>0)&&(sa.getState()==StationState.ON_SERVICE)){ 
				distance = (Point.CalculateDistance(sa.getLocation(),a));
				st = sa;
			}
		}
		return st;
	}


	public BicycleType getBicycleType() {
		return bicycleType;
	}


	public void setBicycleType(BicycleType bicycleType) {
		this.bicycleType = bicycleType;
	}


	public Station[] getOptimalStations() {
		return optimalStations;
	}


	public void setOptimalStations(Station[] optimalStations) {
		this.optimalStations = optimalStations;
	}
    
    



	

	
	
	

	
}
