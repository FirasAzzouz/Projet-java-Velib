package RidePlanning;

import mainClasses.*;       
import otherClasses.*;
import RideUpdating.*;
import java.sql.Timestamp;
import java.util.ArrayList;

import java.util.Scanner;

import CostComputing.*;

/**
 * 
 * @author Diallo
 *
 */
public class Ride implements Observer{
	
	/**
	 * rentalDate is the date of Bicycle rental 
	 * cost is the  variable that will allow us to calculate the cost of the rental 
	 * 
	 * returnDate is the date of the return of our Bicycle 
	 * 
	 * timeCreditAdded is the variable for adding time credits 
	 * 
	 */
	
	private User user;
	private Bicycle bicycle;
	private Station sourceStation;
	private Station destinationStation;
	private Point sourcePoint;
	private Point destinationPoint;
	private ArrayList<Station> stations;
	private RidePlanner rideStrategy;
	private Timestamp rentalDate;
	private Timestamp returnDate;
	private double duration;
	private Station[] optimalStations;
	private RideState rideState;
	private double cost;
	private int timeCreditAdded=0;
	Scanner reader=new Scanner(System.in);
	
	
	public Ride(User user, Point sourcePoint, Point destinationPoint, RidePlanner rideStrategy, ArrayList<Station> stations) {
		super();
		this.user=user;
		user.setRide(this);
		this.stations=stations;
		rideState=RideState.IN_PROGRESS;
		this.sourcePoint=sourcePoint;
		this.destinationPoint=destinationPoint;
		
		optimalStations=rideStrategy.optimalStationsSearch(sourcePoint, destinationPoint, stations);
		sourceStation=optimalStations[0];
		destinationStation=optimalStations[1];
		destinationStation.registerObserver(this);
		
	}
	
	

	public Ride(User user,Station sourceStation) {
		super();
		this.user = user;
		this.sourceStation = sourceStation;
		this.rideState = RideState.IN_PROGRESS;
	}



	@Override
	public void update(Observable o,String notification) {
		user.setNotification(notification);
		/*
		System.out.println("Would you like to recalculate the destination station ?");
		System.out.println("[Y/N]");
		String answer=reader.nextLine();*/
		String answer="Y"; System.out.println("New destination station has been calculated.");
		if (answer.equalsIgnoreCase("Y")) {
			destinationStation=Point.ClosestStationDestinationPoint(destinationPoint, stations);
			destinationStation.registerObserver(this);
		}
	}


	public Station getSourceStation() {
		return sourceStation;
	}

	/**
	 * 
	 * method which 
	 * return the destination Station 
	 */

	public Station getDestinationStation() {
		return destinationStation;
	}


	/**this method which return the RentalDate 
	 */
	public Timestamp getRentalDate() {
		return rentalDate;
	}


	public void setRentalDate(Timestamp rentalDate) {
		this.rentalDate = rentalDate;
	}


	public Timestamp getReturnDate() {
		return returnDate;
	}


	public void setReturnDate(Timestamp returnDate) {
		this.returnDate = returnDate;
	}


	/**
	 * Method returning the State of our ride whether it is in progress our not 
	 * 
	 * 
	 */
	public RideState getRideState() {
		return rideState;
	}


	public void setRideState(RideState rideState) {
		this.rideState = rideState;
	}


	public double getDuration() {
		return duration;
	}


	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	public void setDuration() {
		this.duration= (this.returnDate.getTime()-this.rentalDate.getTime())/(1000*60);
	}



	public double getCost() {
		return cost;
	}


	public void setCost(double cost) {
		this.cost = cost;
	}
	public void setCost() {
		Visitor visitor;
		if (user.getCard() instanceof VlibreCard) {
			visitor=new VlibreCardVisitor();
		}
		else if (user.getCard() instanceof VmaxCard) {
			visitor=new VmaxCardVisitor();
		}
		else  {
			visitor=new NoCardVisitor();
		}
		this.cost = user.getBicycle().accept(visitor);
	}


	public Bicycle getBicycle() {
		return bicycle;
	}


	public void setBicycle(Bicycle bicycle) {
		this.bicycle = bicycle;
	}
	


	public void setDestinationStation(Station destinationStation) {
		this.destinationStation = destinationStation;
	}
	
	



	public int getTimeCreditAdded() {
		return timeCreditAdded;
	}



	public void setTimeCreditAdded(int timeCreditAdded) {
		this.timeCreditAdded = timeCreditAdded;
	}



	@Override
	public String toString() {
		return "Ride [user=" + user.getName() + ", sourceStation=" + sourceStation.getID()
				+ ", destinationStation=" + destinationStation.getID()+ "]";
	}



	public User getUser() {
		return user;
	}



	public Point getSourcePoint() {
		return sourcePoint;
	}



	public Point getDestinationPoint() {
		return destinationPoint;
	}



	public ArrayList<Station> getStations() {
		return stations;
	}



	public RidePlanner getRideStrategy() {
		return rideStrategy;
	}



	public Station[] getOptimalStations() {
		return optimalStations;
	}
	
	
	
	
	
}
