package RidePlanning;

import java.util.ArrayList;   

import mainClasses.*;
import otherClasses.*;

/**
 * 
 * @author Diallo
 *
 */
public class avoid_plus_station implements RidePlanner{
	private BicycleType bicycleType;

	private Station [] optimalStations=new Station[2];
	
	
	
	public avoid_plus_station(BicycleType bicycleType) {
		super();
		this.bicycleType = bicycleType;
	}

	/**
	 * method to find the optimal station to move from a source point "s" to a destination point "d" 
	 * knowing all of the station of our Velib_System . The return station is not a plus station. 
	 * 
	 * So to do so we have defined a method ClosestNotStation which determine 
	 * all the closest station from a source point 
	 * different from a plus station
	 */
	@Override
	public Station[] optimalStationsSearch(Point s,Point d, ArrayList<Station> stations) {
		
		
		optimalStations[0]=Point.ClosestStationSourcePoint(s,stations,bicycleType);
		optimalStations[1]=ClosestNotStationPlus(d,stations);
		return optimalStations;
		
	}
	
	/*
	 * method to find all  the closest station from a point a different from a plus station that we've used in the method above
	 * 
	 * Point a: source point 
	 * s: list of stations of the our system My_veib 
	 */
    public Station ClosestNotStationPlus(Point a, ArrayList<Station> s){
		
		double distance = Float.POSITIVE_INFINITY ;
		Station st = s.get(0);

		for (Station sa : s) {
			if ((Point.CalculateDistance(sa.getLocation(),a)<distance)&& !(sa  instanceof StationPlus) && (sa.getState()==StationState.ON_SERVICE)&&(sa.getFreeSlots()>0)){ 
				distance = (Point.CalculateDistance(sa.getLocation(),a));
				st = sa;
			}
		}
		return st;
	}

	public BicycleType getBicycleType() {
		return bicycleType;
	}

	public void setBicycleType(BicycleType bicycleType) {
		this.bicycleType = bicycleType;
	}

	public Station[] getOptimalStations() {
		return optimalStations;
	}

	public void setOptimalStations(Station[] optimalStations) {
		this.optimalStations = optimalStations;
	}
    
}
