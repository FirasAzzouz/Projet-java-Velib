
package RidePlanning;

import java.util.ArrayList;
import java.util.List;

import mainClasses.*;
import otherClasses.*;

/**
 * 
 * @author Diallo
 *
 */
public class uniformity_preservation implements RidePlanner{
	List<Station> closestSourceStations=new ArrayList<Station>();
	List<Station> closestDestinationStations=new ArrayList<Station>();
	private BicycleType bicycleType;
	private Station [] optimalStations=new Station[2];
	
	
	


	public uniformity_preservation(BicycleType type) {
		super();
		this.bicycleType = type;
	}

	/**
	 * Here we determine the source and destination station such that 
	 * we preserve the uniformity of bicycles distribution amongst stations
	 * 
	 * Our function return the list of station containing source and destination stations.
	 * 	Within our function , we've called closestStations method which finds the closest Station
	 * from a point.  
	 */
	
	
	@Override
	public Station [] optimalStationsSearch(Point s, Point d, ArrayList<Station> stations) {
		
		closestSourceStations=Point.ClosestStationsSourcePoint(s,stations,bicycleType, 105);
		closestDestinationStations=Point.ClosestStationsDestinationPoint(d,stations,105);
		int max=0;
		for (Station st:closestSourceStations) {
			if (st.getNumBicycle(bicycleType)>max) {
				optimalStations[0]=st;
				max=st.getNumBicycle(bicycleType);
			}
		}
		
		max=0;
		for (Station st:closestDestinationStations) {
			if (st.getFreeSlots()>max) {
				optimalStations[1]=st;
				max=st.getFreeSlots();
			}
		}
		
		return optimalStations;
	}
	
	

}
	
	
	


