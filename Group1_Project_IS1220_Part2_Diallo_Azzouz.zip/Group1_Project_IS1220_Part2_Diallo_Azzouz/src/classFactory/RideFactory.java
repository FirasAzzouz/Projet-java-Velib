package classFactory;
import java.util.ArrayList; 
import java.util.Scanner;

import RidePlanning.*;
import otherClasses.*;
import mainClasses.Station;
import mainClasses.User;
import otherClasses.Point;


/**
 * Creates a ride with a certain ride policy, taking into account the desired bicycle type.
 * @author Azzouz
 *
 */
public class RideFactory {
	RidePlanner rideStrategy; //the ride policy
	BicycleType bicycleType; //the desired type of the bicycle
	Scanner reader=new Scanner(System.in); //is used to choose the ride policy
	
	/**
	 * creates a ride for the user from a source point to a destination point.
	 * Allows the user to choose the ride strategy.
	 * @param user: user demanding the creation of the ride
	 * @param sourcePoint: the source point (can be different from the user location)
	 * @param destinationPoint: the destination point 
	 * @param stations: the list of stations in the system
	 * @return a ride with a specific policy
	 */
	public Ride createRide(User user, Point sourcePoint, Point destinationPoint, ArrayList<Station> stations) {
		
		rideStrategy= StrategyChoice();
		Ride ride=new Ride(user, sourcePoint, destinationPoint, rideStrategy, stations);
		
		return ride;
		
	}
	/**
	 * creates a ride for the user from a source point to a destination point. 
	 * @param user: user demanding the creation of the ride
	 * @param sourcePoint: the source point (can be different from the user location)
	 * @param destinationPoint: the destination point
	 * @param rideStrategyStr: the ride strategy
	 * @param bicycleTypeStr: the bicycle type
	 * @param stations: the list of stations in the system
	 * @return
	 */
    public Ride createRide(User user, Point sourcePoint, Point destinationPoint, String rideStrategyStr, String bicycleTypeStr,  ArrayList<Station> stations) {
    	if (bicycleTypeStr.equalsIgnoreCase("MECHANICAL")) {
			bicycleType=BicycleType.MECHANICAL;
		}
    	else if (bicycleTypeStr.equalsIgnoreCase("ELECTRICAL")) {
			bicycleType=BicycleType.ELECTRICAL;
		}
		if (rideStrategyStr.equalsIgnoreCase("minimal_walking_distance")) {
			rideStrategy=new minimal_walking_distance(bicycleType);
		}
		else if (rideStrategyStr.equalsIgnoreCase("fastest_path")) {
			rideStrategy=new fastest_path(bicycleType);
		}
		else if (rideStrategyStr.equalsIgnoreCase("avoid_plus_station")) {
			rideStrategy=new avoid_plus_station(bicycleType);
		}
		else if (rideStrategyStr.equalsIgnoreCase("prefer_plus_station")) {
			rideStrategy=new prefer_plus_station(bicycleType);
		}
		else if (rideStrategyStr.equalsIgnoreCase("uniformity_preservation")) {
			rideStrategy=new uniformity_preservation(bicycleType);
		}
		Ride ride=new Ride(user, sourcePoint, destinationPoint, rideStrategy, stations);
		
		return ride;
	}
	
	/**
	 * Allows the user to choose the ride strategy. In case of a fastest path policy or uniformity preservation policy, it asks
	 * the user to choose a bicycle type.
	 * @return a ride policy
	 */
	public RidePlanner StrategyChoice() {
		System.out.println("");
		bicycleType=bicycleTypeChoice();
		System.out.println("");
		System.out.println("Select one of these ride options:");
		System.out.println("0= minimal walking distance");
		System.out.println("1= fastest path");
		System.out.println("2= avoid plus stations");
		System.out.println("3= prefer plus stations");
		System.out.println("4= uniformity preservations");
		
		System.out.print("Option selected:");
		int n=reader.nextInt();
		
		if (n==0) {
			rideStrategy=new minimal_walking_distance(bicycleType);
		}
		else if (n==1) {
			rideStrategy=new fastest_path(bicycleType);
		}
		else if (n==2) {
			rideStrategy=new avoid_plus_station(bicycleType);
		}
		else if (n==3){
			rideStrategy=new prefer_plus_station(bicycleType);
		}
		else if (n==4){
			rideStrategy=new uniformity_preservation(bicycleType);
		}
		else {
			System.out.println("No Option has been seleceted");
		}
		
		return rideStrategy;
	}
	
	/**
	 * Allows the user to select the desired bicycle
	 * @return the desired bicycle type: ELECTRICAL or MECHANICAL
	 */
	public BicycleType bicycleTypeChoice() {
		System.out.println("What type of bike do you want ?");
		System.out.println("0= Mechanical Bicycle");
		System.out.println("1= Electrical Bicycle");
		System.out.print("Chosen Bicycle:");
		int m= reader.nextInt();
		if (m==0) {
			bicycleType=BicycleType.MECHANICAL;
		}
		else if (m==1){
			bicycleType=BicycleType.ELECTRICAL;
		}
		return bicycleType;
	}
}
