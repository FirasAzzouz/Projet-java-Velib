package classFactory;
import mainClasses.*;
import otherClasses.*;

/**
 * A factory to create cards from different types.
 * @author Azzouz
 *
 */
public class CardFactory {
	/**
	 * creates cards of a given type
	 * @param cardType: type of the card : VLIBRE, VMAX or NOCARD
	 * @return a card of the chosen type
	 */
	public Card createCard (CardType cardType) {
		if (cardType==CardType.VLIBRE){
			return new VlibreCard();
		}
		else if (cardType==CardType.VMAX){
			return new VmaxCard();
		}
		else {
			return new NoCard();
		}
	}
	public Card createCard (String cardTypeString) {
		if (cardTypeString.equalsIgnoreCase("Vlibre")) {
			return new VlibreCard();
		}
		else if (cardTypeString.equalsIgnoreCase("Vmax")) {
			return new VmaxCard();
		}
		else  {
			return new NoCard();
		}
	}

}
