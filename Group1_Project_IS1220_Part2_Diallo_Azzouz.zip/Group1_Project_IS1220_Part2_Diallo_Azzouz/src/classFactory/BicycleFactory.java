package classFactory;
import mainClasses.*;
import otherClasses.*;

/**
 * A factory to create bicycles from different types
 * @author Azzouz
 *
 */
public class BicycleFactory {
	/**
	 * creates a factory from a given type
	 * @param bicycleType: MECHANICAL or ELECTRICAL
	 * @return a bicycle with the chosen type
	 */
	public Bicycle createBicycle(BicycleType bicycleType) {
		if  (bicycleType==BicycleType.ELECTRICAL) {
			return new ElectricalBicycle();
		}
		else if (bicycleType==BicycleType.MECHANICAL) {
			return new MechanicalBicycle();
		}
		else {
			return null;
		}	
	}
}
