package classFactory;
import mainClasses.*;
import otherClasses.*;

/**
 * A factory to create stations from different type.
 * @author Azzouz
 *
 */
public class StationFactory {
	/**
	 * creates a station from a given type 
	 * @param stationType: type of the station :PLUS or STANDARD
	 * @param state: state of the station: ON_SERVICE or OFFLINE
	 * @param nSlots: number of parking slots in the station
	 * @param location: location of the station (latitude, longitude)
	 * @return a station with a specific type
	 */
	public Station createStation(StationType stationType,StationState state, int nSlots, Point location) {
		if (stationType==StationType.PLUS) {
			return new StationPlus(state, nSlots, location);
		}
		else if (stationType==StationType.STANDARD) {
			return new StationStandard(state, nSlots, location);
		}
		else {
			return null;
		}
		
	}

}
