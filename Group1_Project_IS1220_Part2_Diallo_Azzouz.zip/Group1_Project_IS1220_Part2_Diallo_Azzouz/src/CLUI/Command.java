package CLUI;

import java.util.List;
/**
 * Represents a command by its name and its arguments
 * @author Azzouz
 *
 */
public class Command {
	
	private String commandName;
	private List<Object> arguments;
	public Command(String commandName, List<Object> arguments) {
		super();
		this.commandName = commandName;
		this.arguments = arguments;
	}
	public String getCommandName() {
		return commandName;
	}
	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}
	public List<Object> getArguments() {
		return arguments;
	}
	public void setArguments(List<Object> arguments) {
		this.arguments = arguments;
	}
}
