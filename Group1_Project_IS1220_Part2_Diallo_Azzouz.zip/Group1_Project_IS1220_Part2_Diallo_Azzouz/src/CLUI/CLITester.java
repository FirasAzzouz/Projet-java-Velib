package CLUI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mainClasses.*;

public class CLITester {
	public static Map<String,MyVelib> myVelibSystems=new HashMap<String,MyVelib>();
	
	private static Command parseParameters(String[] args) {
		
        final String commandName=args[0];
	    final List<Object> parameters = new ArrayList<>();
	    for (int i=1;i<args.length;i++) {
	    	/*
	    	try{
	    		try {parameters.add(Integer.parseInt(args[i]));}
	    		catch (NumberFormatException e) {parameters.add(Float.parseFloat(args[i]));}
	    	}*/
	    	try {parameters.add(Double.parseDouble(args[i]));}
	    	catch(NumberFormatException e) {parameters.add(args[i]);}
	    }
	    Command command=new Command(commandName, parameters);
	    return command;
	}
	public static void setupCommand(List<Object> arguments) {
		/*int N= Math.round((Float)arguments.get(0));
		int M= N*Math.round((Float)arguments.get(1));
		double bicyclePercentage=(Float)arguments.get(2)*100;
		double electricalPercentage=30;*/
		int freeSlots=0;
		int occupiedSlots=0;
		if (arguments.size()==1) {
			int N=10;
			int M=100;
			int bicyclePercentage=75;
			int electricalPercentage=30;
			
			MyVelib myVelib=new MyVelib(N,M,bicyclePercentage,electricalPercentage);
			String name=null;
			try {
				name=(String)arguments.get(0);
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				for (Station st:myVelib.getStations()) {
					System.out.println(st);
					freeSlots+=st.getFreeSlots();
					occupiedSlots+=st.getOccupiedSlots();
				}
				System.out.println("TotalFreeSlots="+freeSlots);
				System.out.println("TotalOccupiedSlots="+occupiedSlots);
			}
			catch(Exception e) {
				System.out.println("Type Mismatch");
			}
			
		}
		else if (arguments.size()==5) {
			String name=null;
			int N=0;
			int nSlots=0;
			double s=0;
			int nBikes=0;
			try {
				name=(String) arguments.get(0);
				N=(int)(double) arguments.get(1);
				nSlots=(int)(double)arguments.get(2);
				s=(double)arguments.get(3);
				nBikes=(int)(double)arguments.get(4);
				MyVelib myVelib=new MyVelib(N,N*nSlots,(nBikes*100.0)/(nSlots*N),30);
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				for (Station st:myVelib.getStations()) {
					System.out.println(st);
					freeSlots+=st.getFreeSlots();
					occupiedSlots+=st.getOccupiedSlots();
				}
				System.out.println("TotalFreeSlots="+freeSlots);
				System.out.println("TotalOccupiedSlots="+occupiedSlots);
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
		}
		System.out.println("Number of myVelib systems in memory= "+myVelibSystems.size());
	}
	
	public static void main(String[] args) {
		Command command= parseParameters(args);
		String commandName=command.getCommandName();
		List<Object> arguments=command.getArguments();
		if (commandName.equalsIgnoreCase("setup")) {
			setupCommand(arguments);
		}	
	}
}
