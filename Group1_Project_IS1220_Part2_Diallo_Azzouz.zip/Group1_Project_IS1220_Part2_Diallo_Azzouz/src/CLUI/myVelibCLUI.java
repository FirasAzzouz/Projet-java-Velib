package CLUI;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
/**
 * A Command Line User Interface to execute commands and interact with the Velib core
 * @author Azzouz
 *
 */
public class myVelibCLUI {
	public static void main(String[] args) throws Exception{
	    Reader inreader = new InputStreamReader(System.in);
	    CommandInterpreter i = new CommandInterpreter();
	    try {
	        BufferedReader in = new BufferedReader(inreader);
	        String str;
	        while ((str = in.readLine()) != null) {
	            i.runCommand(str);
	        }
	        in.close();
	    } catch (Exception e) {
	    }
	}

}
