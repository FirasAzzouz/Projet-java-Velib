package CLUI;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;


/**
 * A Command Line User Interface to execute commands and interact with the Velib core. It stores the output in a text file.
 * @author Azzouz
 *
 */
public class myVelibCLUI {
	/**
	 * Loads the initial configuration
	 * @param filename: the name of the initial configuration file
	 */
	public static void loadInitialConfig(String filename) {
		try {
			File file = new File(filename);
			BufferedReader br = new BufferedReader(new FileReader(file)); 
			String str; 
			CommandInterpreter i = new CommandInterpreter();
			while ((str = br.readLine()) != null) {
				i.runCommand(str);
			}
			br.close();
		}
		catch(FileNotFoundException e) {System.out.println("Initial Configuration File Not Found: check the file name or location");}
		catch(IOException e) {System.out.println("Problem reading the initial configuration file");}
	}
	/**
	 * Loads the initial configuration and reads the commans written by the user on the command line. It passes the commands
	 * to the command interpreter.
	 * @param args: null
	 */
	public static void main(String[] args) {
		loadInitialConfig("my_velib.ini");
	    Reader inreader = new InputStreamReader(System.in);
	    CommandInterpreter i = new CommandInterpreter();
	    try {
	        BufferedReader in = new BufferedReader(inreader);
	        String str;
	        while ((str = in.readLine()) != null) {
	            i.runCommand(str);
	        }
	        in.close();
	    } catch (Exception e) {
	    }
	}
}
