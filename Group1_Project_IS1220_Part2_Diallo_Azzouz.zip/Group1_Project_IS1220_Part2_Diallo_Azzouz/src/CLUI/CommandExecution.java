package CLUI;

import java.util.List;
import java.util.Map;

import mainClasses.MyVelib;

public interface CommandExecution {
	public void exec(List<Object> arguments, Map<String,MyVelib> myVelibSystems);
}
