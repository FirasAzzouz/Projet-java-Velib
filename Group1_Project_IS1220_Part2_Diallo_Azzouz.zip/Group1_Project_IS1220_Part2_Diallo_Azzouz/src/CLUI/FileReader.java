package CLUI;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class FileReader {
	private static BufferedReader getOutput(Process p) {
        return new BufferedReader(new InputStreamReader(p.getInputStream()));
    }
	public static void readFile(String path){
		try {

			// -- Windows --
			
			// Run a command
			//Process process = Runtime.getRuntime().exec("cmd /c dir C:\\Users\\mkyong");

			//Run a bat file
			
			
			Process process = Runtime.getRuntime().exec(new String[]{"cmd.exe", "/C", "commands.bat"});

			BufferedReader output = getOutput(process);

            String ligne = "";

            while ((ligne = output.readLine()) != null) {
                System.out.println(ligne);
            }
            
			process.waitFor();
			

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		readFile("CLITester.exe");
		
	}
	
}
