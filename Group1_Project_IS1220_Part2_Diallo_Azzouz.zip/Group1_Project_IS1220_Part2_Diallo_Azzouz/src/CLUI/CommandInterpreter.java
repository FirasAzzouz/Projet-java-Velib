package CLUI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import mainClasses.*;
import CommandsList.*;
/**
 * Is used to interpret and execute commands given in the CLUI
 * @author Azzouz
 *
 */
public class CommandInterpreter {
	public static Map<String,MyVelib> myVelibSystems=new HashMap<String,MyVelib>();
	/**
	 * Identifies the command name and its arguments. Transforms, if possible, some arguments to double.
	 * @param str: the variable (String) containing the command written by the user
	 * @return a Command object containing the command name and the arguments
	 */
	private Command parseParameters(String str) {
		String[] words = str.split("\\s+");
        String commandName=words[0];
	    List<Object> arguments = new ArrayList<>();
	    for (int i=1;i<words.length;i++) {
	    	try {arguments.add(Double.parseDouble(words[i]));}
	    	catch(NumberFormatException e) {arguments.add(words[i]);}
	    }
	    Command command=new Command(commandName, arguments);
	    return command;
	}
	/**
	 * Runs the command contained in the line written by the user
	 * @param str: the variable (String) containing the command written by the user
	 */
	public void runCommand(String str) {
		Command command=parseParameters(str);
		CommandExecution commandExec=null;
		if (command.getCommandName().equalsIgnoreCase("setup")){
			commandExec=new SetupCommand();
		}	
		else if (command.getCommandName().equalsIgnoreCase("addUser")) {
			commandExec=new AddUserCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("offline")) {
			commandExec=new OfflineCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("online")) {
			commandExec=new OnlineCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("rentBike")) {
			commandExec=new RentBikeCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("returnBike")) {
			commandExec=new ReturnBikeCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("displayStation")) {
			commandExec=new DisplayStationCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("displayUser")) {
			commandExec=new DisplayUserCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("sortStation")) {
			commandExec=new SortStationCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("display")) {
			commandExec=new DisplayCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("planRide")) {
			commandExec=new PlanRideCommand();
		}
		else if (command.getCommandName().equalsIgnoreCase("runtest")) {
			commandExec=new RunTestCommand();
		}
		try{
			commandExec.exec(command.getArguments(),myVelibSystems);
		}
		catch (NullPointerException e) {
			System.out.println("Cannot recognize the written command");
		}
	}
}
