package RideUpdating;

public interface Observer {
	
	public void update(Observable o,String notification);

}
