package RideUpdating;

/**
 * This interface represents the observable in the observer design pattern.
 * It is implemented by the class station to notify the users through the observer Ride that an incident occured (a station going
 * offline or all the slots being occupied)
 * @author Azzouz
 *
 */
public interface Observable {
	/**
	 * Registers the observers to the station
	 * @param o the observer (the ride)
	 */
	public void registerObserver(Observer o);
	/**
	 * Unregisters the observers to the station
	 * @param o the observer (the ride)
	 */
	public void unregisterObserver(Observer o);
	/**
	 * notifies the observers (Ride) and sends a notification to the users through the class Ride
	 * @param notification: the notification sent to the user: "destination station is offline" or "all the parking slots are 
	 * occupied in the destination station"
	 */
	public void notifyObservers(String notification);
	

}
