package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*; 

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;
import RidePlanning.*;

/**
 * We test the Ride class by checking if the station and destination station are computed and if the destination station registers
 * the ride as an observer.
 * Then we turn the destination station offline during a ride or set the number of free slots to zero and check if the ride is 
 * unregistred from this station and registred to a new destination station. 
 * @author Azzouz
 *
 */
class RideTester {

	MyVelib myVelib;
	double bicyclePercentage=70;
	double electricalPercentage=30;
	ArrayList<Station> stations =new ArrayList<Station>();
	User user1, user2, user3;
	
	/**
	 * Sets up the Velib system using 1 user and 5 stations: 3 plus stations and 2 standard stations.
	 */
	public void createMyVelib() {
		Station st1=new StationPlus(StationState.ON_SERVICE,30,new Point(48.821,2.09));
		Station st2=new StationStandard(StationState.ON_SERVICE,30,new Point(48.822,2.09));
		Station st3=new StationPlus(StationState.ON_SERVICE,30,new Point(48.823,2.09));
		Station st4=new StationStandard(StationState.ON_SERVICE,30,new Point(48.824,2.09));
		Station st5=new StationPlus(StationState.ON_SERVICE,30,new Point(48.825,2.09));
		stations= new ArrayList<Station>(Arrays.asList (st1,st2,st3,st4,st5));	
		user1=new User("Mike", new Point(48.6,2.3),new VlibreCard());
		user2=new User("James", new Point(48.8,2.2),new VmaxCard());
		user3=new User("Max", new Point(48.7,2),new NoCard());
				
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.addUser(user1);
		myVelib.addUser(user2);
		myVelib.addUser(user3);	
	}
		
	/**
	 * We test the registration of the user to the destination station through the class ride.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("******************************** Ride Tester *********************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		Station.n=0;
		createMyVelib();
		
		RidePlanner ridePlanner=new minimal_walking_distance(BicycleType.MECHANICAL);
		Ride ride= new Ride(user1, new Point(48.85,2), new Point(48.7,2),ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		System.out.println("");
		System.out.println("Observers of all stations:" );
		for (Station st:stations) {
			System.out.println("Station "+st.getID()+"= "+st.getObs());
		}
		assertTrue(s2.getObs().contains(ride));
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the update of the destination station when its state changes to OFFLINE.
	 */
	@Test
    void test2() {
		System.out.println("************************************TEST 2************************************");
		Station.n=0;
		createMyVelib();
		
		RidePlanner ridePlanner=new minimal_walking_distance(BicycleType.MECHANICAL);
		Ride ride= new Ride(user1, new Point(48.85,2), new Point(48.7,2),ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		System.out.println("");
		System.out.println("Observers of all stations:" );
		for (Station st:stations) {
			System.out.println("Station "+st.getID()+"= "+st.getObs());
		}
		System.out.println("");
		assertTrue(s2.getObs().contains(ride));
		
		s2.setState(StationState.OFFLINE);
		System.out.println("");
		System.out.println("New Observers of all stations:" );
		for (Station st:stations) {
			System.out.println("Station "+st.getID()+"= "+st.getObs());
		}
		assertFalse(s2.getObs().contains(ride));
		assertTrue(ride.getDestinationStation().getObs().contains(ride));
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
	}
	/**
	 * We test the update of the destination station when there are no more free slots.
	 */
	@Test
    void test3() {
		System.out.println("************************************TEST 3************************************");
		Station.n=0;
		createMyVelib();
		
		RidePlanner ridePlanner=new minimal_walking_distance(BicycleType.MECHANICAL);
		Ride ride= new Ride(user1, new Point(48.85,2), new Point(48.7,2),ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		System.out.println("");
		System.out.println("Observers of all stations:" );
		for (Station st:stations) {
			System.out.println("Station "+st.getID()+"= "+st.getObs());
		}
		System.out.println("");
		assertTrue(s2.getObs().contains(ride));
		
		s2.setAllSlotsOccupied();
		System.out.println("");
		System.out.println("New Observers of all stations:" );
		for (Station st:stations) {
			System.out.println("Station "+st.getID()+"= "+st.getObs());
		}
		assertFalse(s2.getObs().contains(ride));
		assertTrue(ride.getDestinationStation().getObs().contains(ride));
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
}
