package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*; 

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;
import RidePlanning.*;

/**
 * Tests the uniformity_preservation class by printing the distances of the stations to the destination and source points.
 * We then choose the closest stations to the source and the destination points, which present the higher number of available 
 * bicycles of the wanted kind or the higher number of free slots in region no farther than 105% of the closest station and 
 * then compare them with those given by the uniformity_station class.
 * We run other test to check if the policy behaves correctly if a station turns offline.
 * @author Azzouz
 *
 */
class UniformityPreservationTester {
	
	MyVelib myVelib;
	double bicyclePercentage=70;
	double electricalPercentage=30;
	ArrayList<Station> stations =new ArrayList<Station>();
	User user;
	/**
	 * Sets up the Velib system using 1 user and 5 stations: 3 plus stations and 2 standard stations.
	 */
	public void createMyVelib() {
		Station st1=new StationPlus(StationState.ON_SERVICE,30,new Point(48.821,2.09));
		Station st2=new StationStandard(StationState.ON_SERVICE,30,new Point(48.822,2.09));
		Station st3=new StationPlus(StationState.ON_SERVICE,30,new Point(48.823,2.09));
		Station st4=new StationStandard(StationState.ON_SERVICE,30,new Point(48.824,2.09));
		Station st5=new StationPlus(StationState.ON_SERVICE,30,new Point(48.825,2.09));
		stations= new ArrayList<Station>(Arrays.asList (st1,st2,st3,st4,st5));	
		user=new User("Mike", null,new VlibreCard());
	
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.setUsers(new ArrayList<User>(Arrays.asList(user)));
	}

	/**
	 * Tests the uniformity preservation policy using a couple of source and destination points and a mechnical bicycle.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("*********************** Uniformity preservation Tester ************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.80,2.08);
		Point destinationPoint=new Point(48.83,2.10);
		BicycleType bicycleType=BicycleType.MECHANICAL;
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		System.out.println("Desired Bicycle= "+bicycleType);
	
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance + ", number of bicycles of the wanted type= "+stations.get(i).getNumBicycle(bicycleType));
			
			if (distance <minDistanceSource) {
				
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		
		boolean b1=false;
		double minDistanceSourceUniform=minDistanceSource;
		int indexSourceStationUniform=indexSourceStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			b1=distance <minDistanceSource*1.05 && stations.get(i).getNumBicycle(bicycleType)>stations.get(indexSourceStationUniform).getNumBicycle(bicycleType);
			if  (b1){
				indexSourceStationUniform=i;
				minDistanceSourceUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Source Station = "+indexSourceStation+" with "+stations.get(indexSourceStation).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSource);
		System.out.println("Minimum distance (Close Source Station = "+indexSourceStationUniform+" with "+stations.get(indexSourceStationUniform).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSourceUniform);
		System.out.println("");
		
		
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance + ", number of free slots= "+stations.get(i).getFreeSlots());
			if (distance <minDistanceDestination) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		
		boolean b2=false;
		double minDistanceDestinationUniform=minDistanceDestination;
		int indexDestinationStationUniform=indexDestinationStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			b2=distance <minDistanceDestination*1.05 && stations.get(i).getFreeSlots()>stations.get(indexDestinationStationUniform).getFreeSlots();
			if  (b2){
				indexDestinationStationUniform=i;
				minDistanceDestinationUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Destination Station = "+indexDestinationStation+" with "+stations.get(indexDestinationStation).getFreeSlots()+ " free parking slots)= "+minDistanceDestination);
		System.out.println("Minimum distance (Close Destination Station = "+indexDestinationStationUniform+" with "+stations.get(indexDestinationStationUniform).getFreeSlots()+ " free parking slots)= "+minDistanceDestinationUniform);
		System.out.println("");
		
		RidePlanner ridePlanner=new uniformity_preservation(bicycleType);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		
		assertTrue(indexSourceStationUniform==s1.getID());
		assertTrue(indexDestinationStationUniform==s2.getID());
		
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Same setup as test1 but we change the source and destination points and we choose the bicycle to be electrical
	 */
	@Test
	void test2() {
		System.out.println("");
		System.out.println("************************************TEST 2************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.81,2.07);
		Point destinationPoint=new Point(48.825,2.10);
		BicycleType bicycleType=BicycleType.ELECTRICAL;
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		System.out.println("Desired Bicycle= "+bicycleType);
	
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance + ", number of bicycles of the wanted type= "+stations.get(i).getNumBicycle(bicycleType));
			
			if (distance <minDistanceSource) {
				
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		
		boolean b1=false;
		double minDistanceSourceUniform=minDistanceSource;
		int indexSourceStationUniform=indexSourceStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			b1=distance <minDistanceSource*1.05 && stations.get(i).getNumBicycle(bicycleType)>stations.get(indexSourceStationUniform).getNumBicycle(bicycleType);
			if  (b1){
				indexSourceStationUniform=i;
				minDistanceSourceUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Source Station = "+indexSourceStation+" with "+stations.get(indexSourceStation).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSource);
		System.out.println("Minimum distance (Close Source Station = "+indexSourceStationUniform+" with "+stations.get(indexSourceStationUniform).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSourceUniform);
		System.out.println("");
		
		
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance + ", number of free slots= "+stations.get(i).getFreeSlots());
			if (distance <minDistanceDestination) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		
		boolean b2=false;
		double minDistanceDestinationUniform=minDistanceDestination;
		int indexDestinationStationUniform=indexDestinationStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			b2=distance <minDistanceDestination*1.05 && stations.get(i).getFreeSlots()>stations.get(indexDestinationStationUniform).getFreeSlots();
			if  (b2){
				indexDestinationStationUniform=i;
				minDistanceDestinationUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Destination Station = "+indexDestinationStation+" with "+stations.get(indexDestinationStation).getFreeSlots()+ " free parking slots)= "+minDistanceDestination);
		System.out.println("Minimum distance (Close Destination Station = "+indexDestinationStationUniform+" with "+stations.get(indexDestinationStationUniform).getFreeSlots()+ " free parking slots)= "+minDistanceDestinationUniform);
		System.out.println("");
		
		RidePlanner ridePlanner=new uniformity_preservation(bicycleType);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		
		assertTrue(indexSourceStationUniform==s1.getID());
		assertTrue(indexDestinationStationUniform==s2.getID());
		
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Same setup as test 1 but we turn some stations OFFLINE 
	 */
	@Test
	void test3() {
		System.out.println("");
		System.out.println("************************************TEST 3************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.80,2.08);
		Point destinationPoint=new Point(48.83,2.10);
		BicycleType bicycleType=BicycleType.MECHANICAL;
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		System.out.println("Desired Bicycle= "+bicycleType);
		System.out.println("");
		stations.get(0).setState(StationState.OFFLINE);
		stations.get(4).setState(StationState.OFFLINE);
		System.out.println("Stations 0 and 4 are set OFFLINE");
		System.out.println("");
	
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance + ", number of bicycles of the wanted type= "+stations.get(i).getNumBicycle(bicycleType));
			
			if (distance <minDistanceSource &&stations.get(i).getState()==StationState.ON_SERVICE) {
				
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		
		boolean b1=false;
		double minDistanceSourceUniform=minDistanceSource;
		int indexSourceStationUniform=indexSourceStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			b1=distance <minDistanceSource*1.05 && stations.get(i).getNumBicycle(bicycleType)>stations.get(indexSourceStationUniform).getNumBicycle(bicycleType)&&stations.get(i).getState()==StationState.ON_SERVICE;
			if  (b1){
				indexSourceStationUniform=i;
				minDistanceSourceUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Source Station = "+indexSourceStation+" with "+stations.get(indexSourceStation).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSource);
		System.out.println("Minimum distance (Close Source Station = "+indexSourceStationUniform+" with "+stations.get(indexSourceStationUniform).getNumBicycle(bicycleType)+ " bicycles of the desired type)= "+minDistanceSourceUniform);
		System.out.println("");
		
		
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance + ", number of free slots= "+stations.get(i).getFreeSlots());
			if (distance <minDistanceDestination &&stations.get(i).getState()==StationState.ON_SERVICE) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		
		boolean b2=false;
		double minDistanceDestinationUniform=minDistanceDestination;
		int indexDestinationStationUniform=indexDestinationStation;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			b2=distance <minDistanceDestination*1.05 && stations.get(i).getFreeSlots()>stations.get(indexDestinationStationUniform).getFreeSlots()&&stations.get(i).getState()==StationState.ON_SERVICE;
			if  (b2){
				indexDestinationStationUniform=i;
				minDistanceDestinationUniform=distance;
			}
		}
		
		System.out.println("");
		System.out.println("Minimum distance (Destination Station = "+indexDestinationStation+" with "+stations.get(indexDestinationStation).getFreeSlots()+ " free parking slots)= "+minDistanceDestination);
		System.out.println("Minimum distance (Close Destination Station = "+indexDestinationStationUniform+" with "+stations.get(indexDestinationStationUniform).getFreeSlots()+ " free parking slots)= "+minDistanceDestinationUniform);
		System.out.println("");
		
		RidePlanner ridePlanner=new uniformity_preservation(bicycleType);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		
		assertTrue(indexSourceStationUniform==s1.getID());
		assertTrue(indexDestinationStationUniform==s2.getID());
		
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
	
}


