package JUnitTesters;
import mainClasses.*;   
import otherClasses.*;
import RidePlanning.*;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import classFactory.RideFactory;


/**
 * Tests the different constructors of the class MyVelib and checks if the stations are filled according to the specified 
 * percentages
 * @author Diallo
 *
 */
class MyVelibTester {
	MyVelib myVelib;
	
	//int N=5;
	
	ArrayList<Station> stations =new ArrayList<Station>();
	Timestamp t1=new Timestamp(2019,3,2,15,0,0,0);
	Timestamp t2=new Timestamp(2019,3,2,16,15,0,0);
	Timestamp t3=new Timestamp(2019,3,2,17,15,0,0);
	
	User user1;User user2; User user3;
	
	public void createMyVelib() {
		double bicyclePercentage=70;
		double electricalPercentage=30;
		stations.add(new StationPlus(StationState.ON_SERVICE,15,new Point(48.8,2.2)));
		stations.add(new StationStandard(StationState.ON_SERVICE,25,new Point(48.7,2)));
		stations.add(new StationPlus(StationState.ON_SERVICE,20,new Point(48.9,2.1)));
		stations.add(new StationStandard(StationState.ON_SERVICE,25,new Point(48.8,1.9)));
		stations.add(new StationPlus(StationState.ON_SERVICE,15,new Point(48.8,2)));
				
		user1=new User("Mike", new Point(60,2),new VlibreCard());
		user2=new User("James", new Point(65,3),new VmaxCard());
		user3=new User("Max", new Point(62,2),new NoCard());
				
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.addUser(user1);
		myVelib.addUser(user2);
		myVelib.addUser(user3);	
	}
			
	
	
	/**
	 * Tests the first constructor with the stations manually instantiated, then checks the number of occuppied bicycles and the 
	 * number of bicycles from each type
	 */
	@Test
	void test1() {
		
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("******************************* MyVelib Tester *******************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		System.out.println("");
		
		Station.n=0;
		createMyVelib();
		double bicyclePercentage=70;
		double electricalPercentage=30;
		
		int M=myVelib.getTotalSlots();
		int nBicycles=myVelib.getnBicycles();
		System.out.println("Total Number of slots= "+M);
		System.out.println("Number of Bicycles= "+nBicycles);
		assertTrue(M==100);
		assertTrue(nBicycles==70);
		
		int countOccupiedSlots=myVelib.getTotalSlots()-myVelib.getTotalFreeSlots();
		System.out.println("Number of occupied slots= "+ countOccupiedSlots);
		assertTrue(countOccupiedSlots==70);
		
		int countElectricalBicycles=myVelib.getTotalBicycleType(BicycleType.ELECTRICAL);
		System.out.println("Number of electrical bicycles =" +countElectricalBicycles);
		assertTrue(countElectricalBicycles==(int)Math.round(nBicycles*electricalPercentage/100));
		System.out.println("");
		
	}
	/**
	 * Test the second constructor with the station randomly located. Checks if the percentages requirements are met.
	 */
	@Test
	void test2() {
		
		System.out.println("");
		System.out.println("************************************TEST 2************************************");
		System.out.println("");
		
		int N=20;
		int M=310;
		double bicyclePercentage=70;
		double electricalPercentage=30;
		myVelib=new MyVelib(N,M,bicyclePercentage,electricalPercentage);
		for (Station station:myVelib.getStations()) {
			System.out.println(station);
		}
		System.out.println("Total Slots= "+myVelib.getTotalSlots());
		assertTrue(myVelib.getTotalSlots()==M);
		System.out.println("nBicycles "+myVelib.getnBicycles());
		
		assertTrue(myVelib.getnBicycles()==myVelib.getTotalSlots()-myVelib.getTotalFreeSlots());
		
		int countElectricalBicycles=myVelib.getTotalBicycleType(BicycleType.ELECTRICAL);
		System.out.println("Number of electrical bicycles =" +countElectricalBicycles);
		assertTrue(countElectricalBicycles==(int)Math.round(myVelib.getnBicycles()*electricalPercentage/100));
		
	}
	
	

}
