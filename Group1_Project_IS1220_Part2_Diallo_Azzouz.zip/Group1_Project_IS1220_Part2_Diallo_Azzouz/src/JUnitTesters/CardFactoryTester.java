package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;
import mainClasses.*;
import otherClasses.*;
import classFactory.*;

import org.junit.jupiter.api.Test;

/**
 * We test the creation of card through the CardFactory class.
 * @author Diallo
 *
 */
class CardFactoryTester {
	
    /**
     * We check if the created card is of the correct type.
     */
	@Test
	void test() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("****************************** Card Factory Tester ***************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		CardFactory cardFactory=new CardFactory();
		Card c1=cardFactory.createCard(CardType.VLIBRE);
		Card c2=cardFactory.createCard(CardType.VMAX);
		Card c3=cardFactory.createCard(CardType.CREDIT);
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		assertTrue(c1 instanceof VlibreCard);
		assertTrue(c2 instanceof VmaxCard);
		assertTrue(c3 instanceof NoCard);
		System.out.println("");
		System.out.println("TEST ===> OK");
		System.out.println("");
		
	}

}
