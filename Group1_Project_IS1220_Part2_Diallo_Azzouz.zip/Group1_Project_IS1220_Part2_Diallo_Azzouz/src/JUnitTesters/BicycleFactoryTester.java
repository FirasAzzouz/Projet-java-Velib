package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;
import mainClasses.*;
import otherClasses.*;
import classFactory.*;

import org.junit.jupiter.api.Test;

/**
 * We test the creation of bicycles through the BicycleFactory class.
 * @author Diallo
 *
 */
class BicycleFactoryTester {
	
    /**
     * We check if the created bicycle is of the correct type and has the correct ID.
     */
	@Test
	void test() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("*************************** Bicycle Factory Tester ***************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		Bicycle.n=0;
		BicycleFactory bicycleFactory=new BicycleFactory();
		Bicycle b1=bicycleFactory.createBicycle(BicycleType.MECHANICAL);
		Bicycle b2=bicycleFactory.createBicycle(BicycleType.ELECTRICAL);
		Bicycle b3=bicycleFactory.createBicycle(BicycleType.MECHANICAL);
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
		assertTrue(b1 instanceof MechanicalBicycle);
		assertTrue(b2 instanceof ElectricalBicycle);
		assertTrue(b3 instanceof MechanicalBicycle);
		assertTrue(b1.getID()==0);
		assertTrue(b2.getID()==1);
		assertTrue(b3.getID()==2);
		System.out.println("");
		System.out.println("TEST ===> OK");
		System.out.println("");
		
	}

}
