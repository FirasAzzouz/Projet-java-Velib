package JUnitTesters;


import static org.junit.jupiter.api.Assertions.*; 

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;
/**
 * We test the update of the user balance containing: the number of rides, the total time on bike, the total cost and the added time
 * credit.
 * We run a test with 3 users with three different cards and using the two types of bicycles.
 * @author Azzouz
 *
 */
class UserBalanceTester {

	MyVelib myVelib;
	double bicyclePercentage=70;
	double electricalPercentage=30;
	ArrayList<Station> stations =new ArrayList<Station>();
	User user1;
	
	
	/**
	 * Sets up the Velib system using 1 user and 5 stations: 3 plus stations and 2 standard stations.
	 */
	public void createMyVelib() {
		Station st1=new StationPlus(StationState.ON_SERVICE,30,new Point(48.821,2.09));
		Station st2=new StationStandard(StationState.ON_SERVICE,30,new Point(48.822,2.09));
		Station st3=new StationPlus(StationState.ON_SERVICE,30,new Point(48.823,2.09));
		Station st4=new StationStandard(StationState.ON_SERVICE,30,new Point(48.824,2.09));
		Station st5=new StationPlus(StationState.ON_SERVICE,30,new Point(48.825,2.09));
		stations= new ArrayList<Station>(Arrays.asList (st1,st2,st3,st4,st5));	
		user1=new User("Mike", new Point(48.6,2.3),new VlibreCard());
		
				
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.addUser(user1);
			
		
	}
		
	/**
	 * We test the registration of the user to the destination station through the class ride.
	 */
	@Test
	void test() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("**************************** User Balance Tester ******************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		
		Station.n=0;
		createMyVelib();
		Timestamp t1=new Timestamp(2019,3,2,15,0,0,0);
		Timestamp t2=new Timestamp(2019,3,2,16,15,0,0);
		ParkingSlot p1=stations.get(0).findBicycle(BicycleType.MECHANICAL);
		ParkingSlot p2=stations.get(2).findSlot(SlotState.FREE);
		
		user1.rentBicycle(p1, t1);
		user1.returnBicycle(p2, t2);
		System.out.println("User (VLibre card) rents a mechanical bicycle in station 0 and returns it to the plus station 2 after 75 minutes.");
		double duration1=75;
		double cost1= 0.25;
		double addedTimeCredit1=5;
		System.out.println("Duration of Ride 1= "+user1.getRide().getDuration()+" min" );
		System.out.println("Cost of Ride 1= "+ user1.getRide().getCost()+ " euros");
		System.out.println("");
		assertTrue(user1.getRide().getDuration()==duration1);
		assertTrue(user1.getRide().getCost()==cost1);
		
		
		ParkingSlot p3=stations.get(2).findBicycle(BicycleType.ELECTRICAL);
		ParkingSlot p4=stations.get(0).findSlot(SlotState.FREE);
		Timestamp t3=new Timestamp(2019,3,2,17,15,0,0);
		Timestamp t4=new Timestamp(2019,3,2,18,45,0,0);
		user1.rentBicycle(p3, t3);
		user1.returnBicycle(p4, t4);
		double duration2=90;
		double cost2=(double) 1+(25.0/60)*2;
		double addedTimeCredit2=5;
		System.out.println("User (VLibre card) rents an electrical bicycle in station 2 and returns it to the plus station 0 after 90 minutes.");
		System.out.println("Duration of Ride 2= "+user1.getRide().getDuration()+" min" );
		System.out.println("Cost of Ride 2= "+ user1.getRide().getCost()+ " euros");
		System.out.println("");
		assertTrue(user1.getRide().getDuration()==duration2);
		assertTrue(user1.getRide().getCost()==cost2);
		
		ParkingSlot p5=stations.get(0).findBicycle(BicycleType.MECHANICAL);
		ParkingSlot p6=stations.get(1).findSlot(SlotState.FREE);
		Timestamp t5=new Timestamp(2019,3,3,9,00,0,0);
		Timestamp t6=new Timestamp(2019,3,3,10,45,0,0);
		user1.rentBicycle(p5, t5);
		user1.returnBicycle(p6, t6);
		double duration3=105;
		double cost3= (double) 40.0/60;
		double addedTimeCredit3=0;
		System.out.println("User (VLibre card) rents a mechanical bicycle in station 0 and returns it to the standard station 1 after 105 minutes.");
		System.out.println("Duration of Ride 3= "+user1.getRide().getDuration()+" mins" );
		System.out.println("Cost of Ride 3= "+ user1.getRide().getCost()+ " euros");
		System.out.println("");
		assertTrue(user1.getRide().getDuration()==duration3);
		assertTrue(user1.getRide().getCost()==cost3);
		
		System.out.println("Total number of rides for the user= "+user1.getUserBalance().getNumRides());
		System.out.println("Total time on bike= "+user1.getUserBalance().getTotalTimeBike()+ " mins");
		System.out.println("Total charges paid= "+user1.getUserBalance().getTotalChargeRides()+" euros" );
		System.out.println("Total credit time gained= "+user1.getUserBalance().getTimeCreditUser()+ " mins");
		assertTrue(user1.getUserBalance().getNumRides()==3);
		assertTrue(user1.getUserBalance().getTotalTimeBike()==duration1+duration2+duration3);
		assertTrue(user1.getUserBalance().getTotalChargeRides()==cost1+cost2+cost3);
		assertTrue(user1.getUserBalance().getTimeCreditUser()==addedTimeCredit1+addedTimeCredit2+addedTimeCredit3);
		
		System.out.println("");
		System.out.println("TEST ===> OK");
		System.out.println("");
		
	}

}
