package JUnitTesters;

import org.junit.jupiter.api.Test;
import mainClasses.*;
/**
 * 
 * @author Diallo
 *
 */
public class Cardtesting {

	VlibreCard v = new VlibreCard();
	VmaxCard vm = new VmaxCard();

	@Test
	public void test1(){
			
		
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("********************************** Card Tester *******************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		
	
	
	 System.out.println("-----method gettimeCredit----- ");
	System.out.println("ID of v is "+v.getTimeCredit());
	
	
	 System.out.println("-----method getOwner----- ");
	
	 System.out.println("ID of v is "+v.getOwner());
	
	 System.out.println("------------Method addtimecredit--------");
	 
	  v.addTimeCredit(7);
	 
	 System.out.println("the new value of timecredit is "+v.getTimeCredit());
	 
	
}
}

	
	
	
	
//	
//System.out.println("-------------------Bicycle------------------------------");	
//	BicycleFactory BF = new BicycleFactory();
//	
//	Bicycle elctro= BF.createBicycle(BicycleType.ELECTRICAL);
//	Bicycle mechano = BF.createBicycle(BicycleType.MECHANICAL);
//	
//	
//	
//	System.out.println("-------------------------------Station-----------------------------");
//	
//	
//	StationFactory SF = new StationFactory();
//	
//	int nSlots =30;
//	Point location = new Point(12,23);
//	
//	Station plus =SF.createStation(StationType.PLUS, StationState.ON_SERVICE, nSlots, location);
//	
//	
//	System.out.println("-------------------------User--------------------------------");
//	
//	Point s = new Point(1,2);
//	Card d = new VlibreCard();
//	
//	User u = new User("Alassane", s , d);
//	
//	System.
//	
//	System.out.println("");
//	
//	
//	Station a = new Station();
//	ArrayList<Station> s = new ArrayList<Station>(){a,b,c ,d };
//	MyVelib v  = new MyVelib();	
//	MechanicalBicycle b = new MechanicalBicycle();
//	Visitor  v= new  VlibreCardVisitor();		
//	b.accept(v);		
//	
//	
//			
//		}



