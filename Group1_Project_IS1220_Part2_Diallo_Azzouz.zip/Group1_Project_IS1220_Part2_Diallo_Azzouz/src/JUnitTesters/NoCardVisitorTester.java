package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;

/**
 * We test the cost computing after the ride for the two types of bikes (ELECTRICAL and MECHANICAL when the user does not have a
 * Velib  card. We choose different durations and check if the class NoCardVisitor class gives the right cost.
 * @author Diallo
 *
 */
class NoCardVisitorTester {
	Station s1=new StationStandard(StationState.ON_SERVICE,25,new Point (65,1.5));
	Station s2 =new StationPlus(StationState.ON_SERVICE,15,new Point(68,2));
	ParkingSlot p1=new ParkingSlot(s1,SlotState.FREE);
	ParkingSlot p2=new ParkingSlot(s2,SlotState.FREE);
	
	User user=new User("Mike", new Point(60,2),new NoCard());
	
	Bicycle b1=new MechanicalBicycle();
	Bicycle b2=new ElectricalBicycle();
	
	Timestamp t1=new Timestamp(2019,3,2,15,0,0,0);
	Timestamp t2=new Timestamp(2019,3,2,16,15,0,0);
	Timestamp t3=new Timestamp(2019,3,2,17,15,0,0);
	
	int initialTimeCredit;
	int usedTimeCredit;
	int finalTimeCredit;
	double duration;
	double cost;

	
	/**
	 * We test the cost computing when the duration of the ride is 75 mins, the destionation station is a plus station, 
	 * the bicycle is mechanical and the card is a credit card.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("****************** No Card Visitor Tester (Cost computing) *****************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		
		
		b1.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t2);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		
		System.out.println("RentalRecord [Bicycle= Mechanical, User Card= None, Duration= "+duration+", Cost="+cost+"]");
		assertTrue(duration==75);
		assertTrue(cost==75.0/60);
		
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing when the duration of the ride is 135 mins, the destionation station is a plus station, 
	 * the bicycle is mechanical and the card is a credit card.
	 */
	@Test
	void test2() {
		System.out.println("************************************TEST 2************************************");
		
		b1.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Mechanical, User Card= None, Duration= "+duration+", Cost="+cost+"]");
		assertTrue(duration==135);
		assertTrue(cost==135.0/60);
		
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing when the duration of the ride is 75 mins, the destionation station is a plus station, 
	 * the bicycle is electrical and the card is a credit card.
	 */
	@Test
	void test3() {
		System.out.println("************************************TEST 3************************************");
		
		b2.setParkingSlot(p1);
		p2.setState(SlotState.FREE);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t2);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= None, Duration= "+duration+", Cost="+cost+"]");
		assertTrue(duration==75);
		assertTrue(cost==2*75.0/60);
		
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing when the duration of the ride is 135 mins, the destionation station is a plus station, 
	 * the bicycle is electrical and the card is a credit card.
	 */
	@Test
	void test4() {
		System.out.println("************************************TEST 4************************************");
		
		b2.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= None, Duration= "+duration+", Cost="+cost+"]");
		assertTrue(duration==135);
		assertTrue(cost==2*135.0/60);

		System.out.println("");
		System.out.println("TEST 4 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing when the duration of the ride is 135 mins, the destionation station is a standard station, 
	 * the bicycle is electrical and the card is a credit card.
	 */
	@Test
	void test5() {
		System.out.println("************************************TEST 5************************************");
		
		b2.setParkingSlot(p2);
		
		user.rentBicycle(p2, t1);
		user.returnBicycle(p1, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= None, Duration= "+duration+", Cost="+cost+"]");
		assertTrue(duration==135);
		assertTrue(cost==2*135.0/60);

		System.out.println("");
		System.out.println("TEST 5 ===> OK");
		System.out.println("");
	}
}
