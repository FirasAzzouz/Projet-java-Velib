package JUnitTesters;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;

import StationSorting.MostUsedStationSort;
import StationSorting.StationSort;
import StatsComputing.StationBalance;

/**
 * 
 * @author Diallo
 *
 */
public class MostUsedStationTest {
	
	
	
	
//	Comparator<Station> compar = new MostUsedStationComparator();
	
	StationSort stso = new MostUsedStationSort();
	
	
	
	ArrayList<Station> arr = new ArrayList<Station>();
	
	
	Station s1  = new StationPlus(StationState.ON_SERVICE, 45, new Point(12,34));
	Station s2 = new StationPlus(StationState.ON_SERVICE, 40, new Point(10,34));
	Station s3 = new StationPlus(StationState.ON_SERVICE, 9, new Point(112,34));
	Station s4 = new StationPlus(StationState.ON_SERVICE, 8, new Point(103,34));
	User s = new User("ALassane", new Point(12,21),new VlibreCard());
	ArrayList<Station> stations =  new ArrayList<Station>();
	
@Test 
	public void test2() {
	
	StationBalance sb = new StationBalance(s1);
	s1.setStationBalance(sb);
	s2.setStationBalance(sb);
	s3.setStationBalance(sb);
	s4.setStationBalance(sb);
	
	stations.add(s1);
	stations.add(s2);
	stations.add(s3);
	stations.add(s4);
	arr.add(s1);
	arr.add(s2);
	arr.add(s3);
	arr.add(s4);
	stso.sort(arr);
	
	
}
}