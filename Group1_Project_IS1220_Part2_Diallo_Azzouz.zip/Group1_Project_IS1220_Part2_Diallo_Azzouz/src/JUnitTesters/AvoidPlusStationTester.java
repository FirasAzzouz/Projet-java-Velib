package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;
import RidePlanning.*;

/**
 * Tests the avoid_plus_station class by printing the distances of the stations to the destination and source points.
 * We then choose the closest stations to the source point and the closest station to the destination point which is not
 * a plus station and compare them with those given by the avoid_plus_station class.
 * We run other test to check if the policy behaves correctly if a station turns offline, if a station does not contain available
 * bicycles or if a station does not have any free parking slots
 * @author Azzouz
 *
 */
class AvoidPlusStationTester {
	
	MyVelib myVelib;
	double bicyclePercentage=70;
	double electricalPercentage=30;
	ArrayList<Station> stations =new ArrayList<Station>();
	User user;
	/**
	 * Sets up the Velib system using 1 user and 5 stations: 2 plus stations and 3 standard stations.
	 */
	public void createMyVelib() {
		Station st1=new StationStandard(StationState.ON_SERVICE,15,new Point(48.82,2.1));
		Station st2=new StationPlus(StationState.ON_SERVICE,25,new Point(48.83,2.07));
		Station st3=new StationStandard(StationState.ON_SERVICE,20,new Point(48.85,2.12));
		Station st4=new StationPlus(StationState.ON_SERVICE,25,new Point(48.84,2.09));
		Station st5=new StationStandard(StationState.ON_SERVICE,15,new Point(48.81,2.13));
		stations= new ArrayList<Station>(Arrays.asList (st1,st2,st3,st4,st5));	
		user=new User("Mike", null,new VlibreCard());
	
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.setUsers(new ArrayList<User>(Arrays.asList(user)));
	}

	/**
	 * Tests the avoid plus station policy using a first couple of source and destination points
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("************************** Avoid Plus Station Tester *************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.81,2.09);
		Point destinationPoint=new Point(48.84,2.1);
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		user.setPosition(sourcePoint);
		
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance);
			if (distance <minDistanceSource) {
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Source Station = "+indexSourceStation+")= "+minDistanceSource);
		System.out.println("");
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistanceDestination && !(stations.get(i) instanceof StationPlus)) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Not Plus Destination Station = "+indexDestinationStation+")= "+minDistanceDestination);
		System.out.println("");
	
		RidePlanner ridePlanner=new avoid_plus_station(BicycleType.MECHANICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Tests the avoid plus station policy using a second couple of source and destination points.
	 */
	@Test
	void test2() {
		System.out.println("");
		System.out.println("************************************TEST 2************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		user.setPosition(sourcePoint);
		
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance);
			if (distance <minDistanceSource) {
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Source Station = "+indexSourceStation+")= "+minDistanceSource);
		System.out.println("");
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistanceDestination && !(stations.get(i) instanceof StationPlus)) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Not Plus Destination Station = "+indexDestinationStation+")= "+minDistanceDestination);
		System.out.println("");
	
		RidePlanner ridePlanner=new avoid_plus_station(BicycleType.MECHANICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Same setup as test 2 but we turn some stations OFFLINE 
	 */
	@Test
	void test3() {
		System.out.println("");
		System.out.println("************************************TEST 3************************************");
		Station.n=0;
		createMyVelib();
		stations.get(0).setState(StationState.OFFLINE);
		stations.get(2).setState(StationState.OFFLINE);
		System.out.println("Stations 0 and 2 are set OFFLINE");
		System.out.println("");
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		user.setPosition(sourcePoint);
		
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance);
			if (distance <minDistanceSource && stations.get(i).getState()==StationState.ON_SERVICE) {
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (On service Source Station = "+indexSourceStation+")= "+minDistanceSource);
		System.out.println("");
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistanceDestination && stations.get(i).getState()==StationState.ON_SERVICE && !(stations.get(i) instanceof StationPlus)) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (On service Not Plus Destination Station = "+indexDestinationStation+")= "+minDistanceDestination);
		System.out.println("");
	
		RidePlanner ridePlanner=new avoid_plus_station(BicycleType.ELECTRICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
	
	/**
	 * Same setup as test 2 but we change the number of occupied parking slots at the source station to 0 and the number 
	 * of free parking slots to 0 at the destination station.
	 * 
	 */
	@Test
	void test4() {
		System.out.println("");
		System.out.println("************************************TEST 4************************************");
		Station.n=0;
		createMyVelib();
		System.out.println("Station 0 and 2 are now on service");
		stations.get(2).setAllSlotsFree();
		stations.get(0).setAllSlotsOccupied();
		System.out.println("No available bicycles at station 2");
		System.out.println("No free slots at station 0");
		System.out.println("");
		
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		user.setPosition(sourcePoint);
		
		System.out.println("Source Point= "+sourcePoint);
		System.out.println("Destination Point= "+destinationPoint);
		System.out.println("");
		
		double minDistanceSource=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the source point= "+ distance);
			if (distance <minDistanceSource && stations.get(i).getOccupiedSlots()>0) {
				indexSourceStation=i;
				minDistanceSource=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Source station containing available bikes= "+indexSourceStation+")= "+minDistanceSource);
		System.out.println("");
		double minDistanceDestination=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistanceDestination && stations.get(i).getFreeSlots()>0 && !(stations.get(i) instanceof StationPlus)) {
				indexDestinationStation=i;
				minDistanceDestination=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Not Plus Destination Station with free slots= "+indexDestinationStation+")= "+minDistanceDestination);
		System.out.println("");
	
		RidePlanner ridePlanner=new avoid_plus_station(BicycleType.MECHANICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 4 ===> OK");
		System.out.println("");
	}
}

