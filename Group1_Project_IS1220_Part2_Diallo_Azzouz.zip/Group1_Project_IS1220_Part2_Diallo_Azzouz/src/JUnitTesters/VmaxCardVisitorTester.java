package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;

/**
 * We test the cost computing after the ride for the two types of bikes (ELECTRICAL and MECHANICAL when the user card is a VMax 
 * card. We choose different durations and check if the class VmaxCardVisitor class gives the right cost and if the time credit 
 * of the user is correctly updated.
 * @author Diallo
 *
 */
class VmaxCardVisitorTester {
	Station s1=new StationStandard(StationState.ON_SERVICE,25,new Point (65,1.5));
	Station s2 =new StationPlus(StationState.ON_SERVICE,15,new Point(68,2));
	ParkingSlot p1=new ParkingSlot(s1,SlotState.FREE);
	ParkingSlot p2=new ParkingSlot(s2,SlotState.FREE);
	
	User user=new User("Mike", new Point(60,2),new VmaxCard());
	
	Bicycle b1=new MechanicalBicycle();
	Bicycle b2=new ElectricalBicycle();
	
	Timestamp t1=new Timestamp(2019,3,2,15,0,0,0);
	Timestamp t2=new Timestamp(2019,3,2,16,15,0,0);
	Timestamp t3=new Timestamp(2019,3,2,17,15,0,0);
	
	int initialTimeCredit;
	int usedTimeCredit;
	int finalTimeCredit;
	double duration;
	double cost;

	
	/**
	 * We test the cost computing and the time credit update when the initial time credit is 20, the duration of the ride is 75 mins,
	 * the destionation station is a plus station, the bicycle is mechanical and the card is a VMax card.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("****************** VMax Card Visitor Tester (Cost computing) *****************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		
		initialTimeCredit=20;
		user.getCard().setTimeCredit(initialTimeCredit);
		
		b1.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t2);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Mechanical, User Card= VMax, Duration= "+duration+", Cost="+cost+", InitialTimeCredit="+initialTimeCredit+", FinalTimeCredit= "+finalTimeCredit+"]");
		assertTrue(duration==75);
		assertTrue(cost==0);
		assertTrue(finalTimeCredit==10);	
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing and the time credit update when the initial time credit is 20, the duration of the ride is 135 mins,
	 * the destionation station is a plus station, the bicycle is mechanical and the card is a VMax card.
	 */
	@Test
	void test2() {
		System.out.println("************************************TEST 2************************************");
		
		initialTimeCredit=20;
		user.getCard().setTimeCredit(initialTimeCredit);
		
		b1.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Mechanical, User Card= VMax, Duration= "+duration+", Cost="+cost+", InitialTimeCredit="+initialTimeCredit+", FinalTimeCredit= "+finalTimeCredit+"]");
		assertTrue(duration==135);
		assertTrue(cost==55.0/60);
		assertTrue(finalTimeCredit==5);	
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing and the time credit update when the initial time credit is 20, the duration of the ride is 75 mins,
	 * the destionation station is a plus station, the bicycle is electrical and the card is a VMax card.
	 */
	@Test
	void test3() {
		System.out.println("************************************TEST 3************************************");
		
		initialTimeCredit=20;
		user.getCard().setTimeCredit(initialTimeCredit);
		
		b2.setParkingSlot(p1);
		p2.setState(SlotState.FREE);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t2);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= VMax, Duration= "+duration+", Cost="+cost+", InitialTimeCredit="+initialTimeCredit+", FinalTimeCredit= "+finalTimeCredit+"]");
		assertTrue(duration==75);
		assertTrue(cost==0);
		assertTrue(finalTimeCredit==10);	
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing and the time credit update when the initial time credit is 20, the duration of the ride is 135 mins,
	 * the destionation station is a plus station, the bicycle is electrical and the card is a VMax card.
	 */
	@Test
	void test4() {
		System.out.println("************************************TEST 4************************************");
		
		initialTimeCredit=20;
		user.getCard().setTimeCredit(initialTimeCredit);
		
		b2.setParkingSlot(p1);
		
		user.rentBicycle(p1, t1);
		user.returnBicycle(p2, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= VMax, Duration= "+duration+", Cost="+cost+", InitialTimeCredit="+initialTimeCredit+", FinalTimeCredit= "+finalTimeCredit+"]");
		assertTrue(duration==135);
		assertTrue(cost==55.0/60);
		assertTrue(finalTimeCredit==5);	
		System.out.println("");
		System.out.println("TEST 4 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We test the cost computing and the time credit update when the initial time credit is 20, the duration of the ride is 135 mins,
	 * the destionation station is a standard station, the bicycle is electrical and the card is a VMax card.
	 */
	@Test
	void test5() {
		System.out.println("************************************TEST 5************************************");
		
		initialTimeCredit=20;
		user.getCard().setTimeCredit(initialTimeCredit);
		
		b2.setParkingSlot(p2);
		
		user.rentBicycle(p2, t1);
		user.returnBicycle(p1, t3);

		cost=user.getRide().getCost();
		duration=user.getRide().getDuration();
		finalTimeCredit=user.getCard().getTimeCredit();
		
		System.out.println("RentalRecord [Bicycle= Electrical, User Card= VMax, Duration= "+duration+", Cost="+cost+", InitialTimeCredit="+initialTimeCredit+", FinalTimeCredit= "+finalTimeCredit+"]");
		assertTrue(duration==135);
		assertTrue(cost==55.0/60);
		assertTrue(finalTimeCredit==0);	
		System.out.println("");
		System.out.println("TEST 5 ===> OK");
		System.out.println("");
	}
}
