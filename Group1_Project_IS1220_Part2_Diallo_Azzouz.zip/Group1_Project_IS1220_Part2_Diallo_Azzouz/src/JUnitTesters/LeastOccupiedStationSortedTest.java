package JUnitTesters;


import java.sql.Timestamp; 

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import mainClasses.*;
import otherClasses.*;

import StationSorting.*;
import StatsComputing.StationBalance;

/**
 * 
 * @author Diallo
 *
 */
public class LeastOccupiedStationSortedTest {
	
	
	Timestamp te = Timestamp.valueOf("2019-04-12 10:50:45");
	Timestamp ts = Timestamp.valueOf("2019-04-12 09:45:45");

	StationSort s = new LeastOccupiedStationSort(te,ts);

	
	
	ArrayList<Station> arr = new ArrayList<Station>();
	
	
	Station s1  = new StationPlus(StationState.ON_SERVICE, 45, new Point(12,34));
	Station s2 = new StationPlus(StationState.ON_SERVICE, 40, new Point(10,34));
	Station s3 = new StationPlus(StationState.ON_SERVICE, 9, new Point(12,24));
	Station s4 = new StationPlus(StationState.ON_SERVICE, 8, new Point(13,64));
	
	
@Test 
	public void test2() {
	

	StationBalance sb = new StationBalance(s1);
	s1.setStationBalance(sb);
	s2.setStationBalance(sb);
	s3.setStationBalance(sb);
	s4.setStationBalance(sb);
	
	
	arr.add(s1);
	arr.add(s2);
	arr.add(s3);
	arr.add(s4);
	s.sort(arr);
	
	
}




	
}
