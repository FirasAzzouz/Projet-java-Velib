package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;

import mainClasses.*;
import otherClasses.*;
import StatsComputing.*;

import org.junit.jupiter.api.Test;
/**
 * We check if the values given by the StationBalance are correct or not. We test different scenarios where the rents and returns 
 * are inside or outside the time window.
 * @author Azzouz
 *
 */
class StationBalanceTester {
	
	
	/**
	 * We check the station balance variables values if there are no rents and no returns.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("************************** Station Balance Tester ****************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("***********************************Test 1*************************************");
		System.out.println("");
		Timestamp ts=new Timestamp(2019,3,0,15,0,0,0);
		Timestamp te=new Timestamp(2019,3,7,15,0,0,0);
		Station st=new StationPlus(StationState.ON_SERVICE,5,new Point(48.9,2.1));
		ParkingSlot p1=new ParkingSlot(st,SlotState.FREE);
		p1.setBicycle(new MechanicalBicycle());
		ParkingSlot p2=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p3=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p4=new ParkingSlot(st,SlotState.FREE);
		p4.setBicycle(new ElectricalBicycle());
		ParkingSlot p5=new ParkingSlot(st,SlotState.FREE);
		p5.setState(SlotState.OUT_OF_ORDER);
		System.out.println(new StationBalance(st,ts,te));
		assertTrue(st.getStationBalance().getAverageRateOccupation()==0.6);
		assertTrue(st.getStationBalance().getNumRentsOperations()==0);
		assertTrue(st.getStationBalance().getNumReturnsOperations()==0);
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We check the station balance variables values if there rents and some returns, all outside the time window.
	 */
	@Test
	void test2() {
		System.out.println("");
		System.out.println("***********************************Test 2*************************************");
		System.out.println("");
		User user1=new User("Mike", new Point(48.6,2.3),new VlibreCard());
		User user2=new User("James", new Point(48.7,2.2),new VlibreCard());
		Timestamp ts=new Timestamp(2019,3,0,15,0,0,0);
		Timestamp te=new Timestamp(2019,3,0,16,0,0,0);
		Station st=new StationPlus(StationState.ON_SERVICE,5,new Point(48.9,2.1));
		ParkingSlot p1=new ParkingSlot(st,SlotState.FREE);
		p1.setBicycle(new MechanicalBicycle());
		ParkingSlot p2=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p3=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p4=new ParkingSlot(st,SlotState.FREE);
		p4.setBicycle(new ElectricalBicycle());
		ParkingSlot p5=new ParkingSlot(st,SlotState.FREE);
		p5.setState(SlotState.OUT_OF_ORDER);
		
		user1.rentBicycle(p1,new Timestamp(2019,2,0,15,0,0,0));
		user1.returnBicycle(p2,new Timestamp(2019,2,0,16,0,0,0));
		user2.rentBicycle(p4,new Timestamp(2019,2,0,15,30,0,0));
		
		System.out.println(new StationBalance(st,ts,te));
		assertTrue(st.getStationBalance().getAverageRateOccupation()==0.6);
		assertTrue(st.getStationBalance().getNumRentsOperations()==2);
		assertTrue(st.getStationBalance().getNumReturnsOperations()==1);
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
	}
	
	
	/**
	 * We check the station balance variables values if there rents and some returns, all inside the time window.
	 */
	@Test
	void test3() {
		System.out.println("");
		System.out.println("***********************************Test 3*************************************");
		System.out.println("");
		User user1=new User("Mike", new Point(48.6,2.3),new VlibreCard());
		User user2=new User("James", new Point(48.7,2.2),new VlibreCard());
		Timestamp ts=new Timestamp(2019,3,0,15,0,0,0);
		Timestamp te=new Timestamp(2019,3,0,16,0,0,0);
		Station st=new StationPlus(StationState.ON_SERVICE,5,new Point(48.9,2.1));
		ParkingSlot p1=new ParkingSlot(st,SlotState.FREE);
		(new MechanicalBicycle()).setParkingSlot(p1);
		ParkingSlot p2=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p3=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p4=new ParkingSlot(st,SlotState.FREE);
		(new ElectricalBicycle()).setParkingSlot(p4);
		ParkingSlot p5=new ParkingSlot(st,SlotState.FREE);
		p5.setState(SlotState.OUT_OF_ORDER);
		
		user1.rentBicycle(p1,new Timestamp(2019,3,0,15,15,0,0));
		user1.returnBicycle(p2,new Timestamp(2019,3,0,15,45,0,0));
		user2.rentBicycle(p4,new Timestamp(2019,3,0,15,30,0,0));
		
		System.out.println(new StationBalance(st,ts,te));
		assertTrue(st.getStationBalance().getAverageRateOccupation()==(15+15+30+60.0)/(60*5));
		assertTrue(st.getStationBalance().getNumRentsOperations()==2);
		assertTrue(st.getStationBalance().getNumReturnsOperations()==1);
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
	}
	
	/**
	 * We check the station balance variable values if there rents and some returns, some of which are inside the time window, some
	 * are outside of it.
	 */
	@Test
	void test4() {
		System.out.println("");
		System.out.println("***********************************Test 4*************************************");
		System.out.println("");
		User user1=new User("Mike", new Point(48.6,2.3),new VlibreCard());
		User user2=new User("James", new Point(48.7,2.2),new VlibreCard());
		User user3=new User("Max", new Point(48.7,2.2),new VlibreCard());
		User user4=new User("Steph", new Point(48.7,2.2),new VlibreCard());
		User user5=new User("John", new Point(48.7,2.2),new VlibreCard());
		Timestamp ts=new Timestamp(2019,3,0,15,0,0,0);
		Timestamp te=new Timestamp(2019,3,0,16,0,0,0);
		Station st=new StationPlus(StationState.ON_SERVICE,8,new Point(48.9,2.1));
		ParkingSlot p1=new ParkingSlot(st,SlotState.FREE);
		(new MechanicalBicycle()).setParkingSlot(p1);
		ParkingSlot p2=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p3=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p4=new ParkingSlot(st,SlotState.FREE);
		(new ElectricalBicycle()).setParkingSlot(p4);
		ParkingSlot p5=new ParkingSlot(st,SlotState.FREE);
		p5.setState(SlotState.OUT_OF_ORDER);
		ParkingSlot p6=new ParkingSlot(st,SlotState.FREE);
		(new MechanicalBicycle()).setParkingSlot(p6);
		ParkingSlot p7=new ParkingSlot(st,SlotState.FREE);
		ParkingSlot p8=new ParkingSlot(st,SlotState.FREE);
		(new MechanicalBicycle()).setParkingSlot(p8);
		
		
		user1.rentBicycle(p1,new Timestamp(2019,3,0,15,15,0,0));
		user1.returnBicycle(p2,new Timestamp(2019,3,0,16,45,0,0));
		user2.rentBicycle(p4,new Timestamp(2019,3,0,14,30,0,0));
		user2.returnBicycle(p3,new Timestamp(2019,3,0,16,30,0,0));
		user3.rentBicycle(p6,new Timestamp(2019,3,0,14,15,0,0));
		user3.returnBicycle(p7,new Timestamp(2019,3,0,15,30,0,0));
		user4.rentBicycle(p7,new Timestamp(2019,3,0,15,35,0,0));
		user4.returnBicycle(p1, new Timestamp(2019,3,0,15,55,0,0));
		user5.rentBicycle(p8,new Timestamp(2019,3,0,15,05,0,0));
		
		System.out.println(new StationBalance(st,ts,te));
		assertTrue(st.getStationBalance().getAverageRateOccupation()==((double)15+5+5+5+60)/(60*8));
		assertTrue(st.getStationBalance().getNumRentsOperations()==5);
		assertTrue(st.getStationBalance().getNumReturnsOperations()==4);
		System.out.println("");
		System.out.println("TEST 4 ===> OK");
		System.out.println("");
	}


}
