package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*; 

import org.junit.jupiter.api.Test;
import otherClasses.*;

/**
 * We test the computation of distance between two points on earth using their latitude and longitude: We take some specific points 
 * on earth like the two poles and we compute the distance using the distance function of class point and compare it to a locally
 * calculated distance which expression is easy. Then we take some points on earth and we compare the values given by the function
 * in class Point to values found on internet using advanced calculation tools. We round the numbers to 2 decimals to have a 
 * valid comparison.
 * We don't test here the static methods in class Point because they are tested in the testers of the ride policies.
 * @author Azzouz
 *
 */
class PointTester {
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("******************************** Point Tester ********************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("Testing the distance computation");
		System.out.println("");
		
		Point p1=new Point (48.8,2.1);
		Point p2=new Point (48.9,2.0);
		Point p3=new Point (48.7,2.2);
		System.out.println("Distance between "+p1+" and "+p2+" = "+(double)Math.round(Point.CalculateDistance(p1, p2)*100)/100);
		assertTrue((double)Math.round(Point.CalculateDistance(p1, p2)*100)/100==13.31);
		System.out.println("Distance between "+p1+" and "+p3+" = "+(double)Math.round(Point.CalculateDistance(p1, p3)*100)/100);
		assertTrue((double)Math.round(Point.CalculateDistance(p1, p3)*100)/100==13.32);
		System.out.println("Distance between "+p2+" and "+p3+" = "+(double)Math.round(Point.CalculateDistance(p2, p3)*100)/100);
		assertTrue((double)Math.round(Point.CalculateDistance(p2, p3)*100)/100==26.63);
		
		
		double R=6371; //earth radius
		Point p4=new Point(-90,0);
		Point p5=new Point(0,0);
		Point p6=new Point(90,0);
		Point p7=new Point(0,180);
		assertTrue(Point.CalculateDistance(p4, p5)==R*Math.PI/2);
		assertTrue(Point.CalculateDistance(p4, p6)==R*Math.PI);
		assertTrue(Point.CalculateDistance(p5, p7)==R*Math.PI);
		System.out.println("");
		System.out.println("TEST ===> OK");
		System.out.println("");	
	}
}
