package JUnitTesters;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import mainClasses.*;
import otherClasses.*;
import classFactory.*;

/**
 * 
 * @author Diallo
 *
 */
public class StationTest {
	
	StationFactory SF = new StationFactory();
	int nSlots =30;
    Point location = new Point(12,23);

    Station plus =SF.createStation(StationType.PLUS, StationState.ON_SERVICE, nSlots, location);
	@Test
	public void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("********************************* Station Tester *****************************");
		System.out.println("******************************************************************************");
		System.out.println("");

		
	
	
		System.out.println("-------method to obtain the number of slots "+plus.getFreeSlots());
		
		
		
		
	}
	@Test
	
	public void test2(){
		
		 
			System.out.println("-------method to obtain the number of ElectricalBicylce "+plus.getNumBicycle(BicycleType.ELECTRICAL));
			
		
		
		
	}
	@Test
	public void test3(){
		
			System.out.println("-------method to obtain the location "+plus.getLocation());
			
			
		
		
		
	}
	@Test
	public void test4() {
		

		
		
		ArrayList<ParkingSlot> park = new ArrayList<ParkingSlot>();
		
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.OCCUPIED));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		
		
		
		for (ParkingSlot p :park) {
			
			System.out.println(p.toString());
		}
		
	}
	
	
	
	
	
	@Test 
	public void test5() 
	{
		System.out.println("---------------------ANother test-------------------------");

		ArrayList<ParkingSlot> park = new ArrayList<ParkingSlot>();
		ParkingSlot p =new ParkingSlot(plus,SlotState.FREE);
		Bicycle bicycle = new ElectricalBicycle();
		p.setBicycle(bicycle);
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(new ParkingSlot(plus,SlotState.FREE));
		park.add(p);

		for (ParkingSlot c :park) {
			
			System.out.println(c.toString());
		}
		
	}
		
	
	
	
	}
		
		
		
		
	


