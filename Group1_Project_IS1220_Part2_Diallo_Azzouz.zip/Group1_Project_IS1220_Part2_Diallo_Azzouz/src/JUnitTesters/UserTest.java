package JUnitTesters;
import java.sql.Timestamp; 
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import RidePlanning.RidePlanner;
import StatsComputing.UserBalance;
import mainClasses.*;
import otherClasses.*;
import classFactory.BicycleFactory;
import classFactory.CardFactory;
import RidePlanning.*;

/**
 * 
 * @author Diallo
 *
 */
public class UserTest {
	
	User s = new User("ALassane", new Point(12,21),new VlibreCard());
	
	User e = new User("Azzouz", new Point(12,10), new VmaxCard());
	
	StationPlus p = new StationPlus(StationState.OFFLINE,34,new Point(12,34));
	
	StationStandard d = new StationStandard(StationState.ON_SERVICE,34,new Point(2,4));
	
	ArrayList<Station> stations = new ArrayList<Station>();
	UserBalance user = new UserBalance(s);
	BicycleFactory BF = new BicycleFactory();
	RidePlanner rd = new fastest_path(BicycleType.ELECTRICAL);
	CardFactory CF = new CardFactory();
	
	Card cd = CF.createCard(CardType.VLIBRE);
	
	
	
	
	
	@Test
	public void test1(){
		
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("*********************************** User Tester ******************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************Test1*************************************" );
		System.out.println("");

		
		user.setNumRides(12);
		user.setTimeCreditUser(12.5);
		user.setTotalChargeRides(19);
		user.setTotalTimeBike(10);
		user.setUser(s);
		
	}
	@Test
	public void test2() {
		
		System.out.println("");
		System.out.println("************************************Test2*************************************" );
		System.out.println("");
		
		stations.add(p);
		stations.add(d);
		
		s.setNotification("Emprunt Bike");
		
		s.setBicycle(BF.createBicycle(BicycleType.MECHANICAL));
		s.setUserBalance(user);
		Ride r = new Ride(s, new Point(12,1), new Point(12,45), rd, stations);
		s.setRide(r);
		s.setCard(cd);
		s.setNotification("Renting ");
	
		
}	
Station s1  = new StationPlus(StationState.ON_SERVICE, 45, new Point(12,34));
ParkingSlot slot = new ParkingSlot(s1, SlotState.FREE);


@Test  
public void test3() {
	System.out.println("");
	System.out.println("************************************Test4*************************************" );
	System.out.println("");

	stations.add(d);
	stations.add(p);
	ParkingSlot slot1 = new ParkingSlot(d, SlotState.FREE);
	ParkingSlot slot2 = new ParkingSlot(p, SlotState.FREE);
	(new MechanicalBicycle()).setParkingSlot(slot1);
	Ride r = new Ride(s, new Point(12,1), new Point(12,45), rd, stations);
	
	s.rentBicycle(slot1,Timestamp.valueOf("2019-05-13 06:12:14"));
	s.setCard(cd);
	s.setNotification("Renting ");
	s.returnBicycle(slot2, Timestamp.valueOf("2019-05-13 07:12:14"));
	
}
}
