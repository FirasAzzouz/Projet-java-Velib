package JUnitTesters;
import org.junit.jupiter.api.Test;

import StatsComputing.StationBalance;
import mainClasses.*;
import otherClasses.*;


/**
 * 
 * @author Diallo
 *
 */
public class StationPLusTest {
	
	
	
Station st  = new StationPlus(StationState.ON_SERVICE, 45, new Point(12,34));
Station ste = new StationPlus(StationState.ON_SERVICE, 40, new Point(10,34));


@Test
private void test_1() {
	System.out.println("");
	System.out.println("******************************************************************************");
	System.out.println("****************************** StationPlus Tester ****************************");
	System.out.println("******************************************************************************");
	System.out.println("");

	
	StationBalance stat = new StationBalance(st);
	st.setStationBalance(stat );
	ste.setStationBalance(stat);
	System.out.println(st.getLocation());
	System.out.println(ste.getLocation());
	
}

}
