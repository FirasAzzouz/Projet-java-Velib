package JUnitTesters;
import java.sql.Timestamp; 

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import mainClasses.*;
import otherClasses.*;
import classFactory.*;


/**
 * 
 * @author Diallo
 *
 */
public class ParkingSlotTest {
	
	

	StationFactory SF = new StationFactory();
	int nSlots = 45;
	Point location = new Point(12,45);
	Station s = SF.createStation(StationType.PLUS, StationState.OFFLINE, nSlots, location);
	ParkingSlot ps = new ParkingSlot(s,SlotState.FREE);
	ParkingSlot pa = new ParkingSlot(s, SlotState.OCCUPIED);

	Timestamp te = Timestamp.valueOf("2019-03-19 05:14:22");
	Timestamp ts= Timestamp.valueOf("2019-03-09 08:00:00");
	@Test 
	public void Test(){
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("****************************** Parking slot Tester ***************************");
		System.out.println("******************************************************************************");
		System.out.println("");


		
		
		
		ps.setState(SlotState.OCCUPIED,  te );
		ps.setState(SlotState.FREE,ts);
		
		System.out.println(ps.getState());
		
		
	}
	@Test 
	public void test2(){
		
		System.out.println(ps.toString());
		System.out.println(pa.toString());
		
		ArrayList<Timestamp> s = new ArrayList<Timestamp>();
		
		s.add(Timestamp.valueOf("2019-03-10 12:00:00"));
		s.add(Timestamp.valueOf("2019-03-11 12:00:00"));
		s.add(Timestamp.valueOf("2019-03-12 12:00:00"));
		s.add(Timestamp.valueOf("2019-03-13 12:00:00"));
		ps.setTi(s);
		
		
		ArrayList<Timestamp> tj = new ArrayList<Timestamp>();
		

		tj.add(Timestamp.valueOf("2019-03-10 12:00:05"));
		tj.add(Timestamp.valueOf("2019-03-11 12:00:05"));
		tj.add(Timestamp.valueOf("2019-03-12 12:00:05"));
		tj.add(Timestamp.valueOf("2019-03-13 12:00:05"));
		ps.setTj(tj);
		
		
		System.out.println(ps.getTj());
		
		
	}
	
	
}
