package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import mainClasses.*;
import otherClasses.*;
import RidePlanning.*;

/**
 * Tests the fastest_path class by printing the time taken for all possible rides and the distance between the destination point
 * and all the stations. 
 * We then choose the source station corresponding to the fastest path and the closest destination station to the 
 * destination point and compare them with those given by the fastes_path class.
 * We run these tests on the same setup of the station but with different source and destination points. We then turn some stations
 * offline or set the number of free parking slots to zero or the number of occupied parking slots to zero in certain stations 
 * to check if the planner does not pick them.
 * @author Azzouz
 *
 */
class FastestPathTester {
	MyVelib myVelib;
	double bicyclePercentage=70;
	double electricalPercentage=30;
	ArrayList<Station> stations =new ArrayList<Station>();
	User user;
	/**
	 * Sets up the Velib system using 5 stations and 1 user.
	 */
	public void createMyVelib() {
		Station st1=new StationPlus(StationState.ON_SERVICE,15,new Point(48.82,2.1));
		Station st2=new StationStandard(StationState.ON_SERVICE,25,new Point(48.83,2.07));
		Station st3=new StationPlus(StationState.ON_SERVICE,20,new Point(48.85,2.12));
		Station st4=new StationStandard(StationState.ON_SERVICE,25,new Point(48.84,2.09));
		Station st5=new StationPlus(StationState.ON_SERVICE,15,new Point(48.81,2.13));
		stations= new ArrayList<Station>(Arrays.asList (st1,st2,st3,st4,st5));	
		user=new User("Mike", null,new VlibreCard());
	
		myVelib=new MyVelib(stations, bicyclePercentage,electricalPercentage);
		myVelib.setUsers(new ArrayList<User>(Arrays.asList(user)));
	}

	/**
	 * Tests the fastest path policy using a first couple of source and destination points, and a mechanical bicycle.
	 */
	@Test
	void test1() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("**************************** Fastest Path Tester *****************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		System.out.println("************************************TEST 1************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.81,2.09);
		Point destinationPoint=new Point(48.84,2.1);
		user.setPosition(sourcePoint);
		
		double minDuration=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			for (int j=0; j<stations.size();j++) {
				double t1=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation())/4;
				double t2=Point.CalculateDistance(destinationPoint, stations.get(j).getLocation())/4;
				double t3=Point.CalculateDistance(stations.get(i).getLocation(), stations.get(j).getLocation())/15;
				System.out.println("Duration (Source station= "+i+", Destination station= "+j+")= "+(t1+t2+t3));
				if (t1+t2+t3<minDuration) {
					minDuration=t1+t2+t3;
					indexSourceStation=i;
				}
			}
		}
		System.out.println("");
		System.out.println("Minimum Duration (Source station= "+indexSourceStation+")= "+minDuration);
		System.out.println("");
		double minDistance=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistance) {
				indexDestinationStation=i;
				minDistance=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Destination Station = "+indexDestinationStation+")= "+minDistance);
		System.out.println("");
		
		RidePlanner ridePlanner=new fastest_path(BicycleType.MECHANICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 1 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Tests the fastest path policy using a second couple of source and destination points, and an electrical bicycle.
	 */
	@Test
	void test2() {
		System.out.println("");
		System.out.println("************************************TEST 2************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		user.setPosition(sourcePoint);
		
		
		double minDuration=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			for (int j=0; j<stations.size();j++) {
				double t1=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation())/4;
				double t2=Point.CalculateDistance(stations.get(i).getLocation(), stations.get(j).getLocation())/20;
				double t3=Point.CalculateDistance(destinationPoint, stations.get(j).getLocation())/4;
				System.out.println("Duration (Source station= "+i+", Destination station= "+j+")= "+(t1+t2+t3));
				if (t1+t2+t3<minDuration) {
					minDuration=t1+t2+t3;
					indexSourceStation=i;
				}
			}
		}
		System.out.println("");
		System.out.println("Minimum Duration (Source station= "+indexSourceStation+")= "+minDuration);
		System.out.println("");
		double minDistance=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistance) {
				indexDestinationStation=i;
				minDistance=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (On service Destination Station = "+indexDestinationStation+")= "+minDistance);
		System.out.println("");
		
		RidePlanner ridePlanner=new fastest_path(BicycleType.ELECTRICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 2 ===> OK");
		System.out.println("");
		
	}
	
	/**
	 * Same setup as test 2 but we set some stations offline
	 */
	@Test
	void test3() {
		System.out.println("");
		System.out.println("************************************TEST 3************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		user.setPosition(sourcePoint);
		
		stations.get(0).setState(StationState.OFFLINE);
		stations.get(3).setState(StationState.OFFLINE);
		System.out.println("Stations 0 and 3 are set OFFLINE.");
		System.out.println("");
		double minDuration=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			for (int j=0; j<stations.size();j++) {
				double t1=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation())/4;
				double t2=Point.CalculateDistance(stations.get(i).getLocation(), stations.get(j).getLocation())/20;
				double t3=Point.CalculateDistance(destinationPoint, stations.get(j).getLocation())/4;
				System.out.println("Duration (Source station= "+i+", Destination station= "+j+")= "+(t1+t2+t3));
				if (t1+t2+t3<minDuration && stations.get(i).getState()==StationState.ON_SERVICE) {
					minDuration=t1+t2+t3;
					indexSourceStation=i;
				}
			}
		}
		System.out.println("");
		System.out.println("Minimum Duration (On service source station= "+indexSourceStation+")= "+minDuration);
		System.out.println("");
		double minDistance=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistance && stations.get(i).getState()==StationState.ON_SERVICE) {
				indexDestinationStation=i;
				minDistance=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (On service Destination Station = "+indexDestinationStation+")= "+minDistance);
		System.out.println("");
		
		RidePlanner ridePlanner=new fastest_path(BicycleType.ELECTRICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 3 ===> OK");
		System.out.println("");
		
	}
	/**
	 * Same setup as test 2 but we change the state of all parking slots in the source station to Free and the state of all
	 * parking slots in the destination station to Occupied.
	 */
	@Test
	void test4() {
		System.out.println("");
		System.out.println("************************************TEST 4************************************");
		Station.n=0;
		createMyVelib();
		Point sourcePoint=new Point(48.84,2.11);
		Point destinationPoint=new Point(48.81,2.09);
		user.setPosition(sourcePoint);
		
		System.out.println("Station 0 and 2 are now on service");
		stations.get(0).setAllSlotsOccupied();;
		stations.get(3).setAllSlotsFree();
		System.out.println("No available bicycles at station 3");
		System.out.println("No free slots at station 0");
		System.out.println("");
		
		double minDuration=Float.POSITIVE_INFINITY;
		int indexSourceStation=0;
		for (int i=0;i<stations.size();i++) {
			for (int j=0; j<stations.size();j++) {
				double t1=Point.CalculateDistance(sourcePoint, stations.get(i).getLocation())/4;
				double t2=Point.CalculateDistance(stations.get(i).getLocation(), stations.get(j).getLocation())/20;
				double t3=Point.CalculateDistance(destinationPoint, stations.get(j).getLocation())/4;
				System.out.println("Duration (Source station= "+i+", Destination station= "+j+")= "+(t1+t2+t3));
				if (t1+t2+t3<minDuration && stations.get(i).getOccupiedSlots()>0 && stations.get(j).getFreeSlots()>0) {
					minDuration=t1+t2+t3;
					indexSourceStation=i;
				}
			}
		}
		System.out.println("");
		System.out.println("Minimum Duration (Source station containing available bikes= "+indexSourceStation+")= "+minDuration);
		System.out.println("");
		double minDistance=Float.POSITIVE_INFINITY;
		int indexDestinationStation=0;
		for (int i=0;i<stations.size();i++) {
			double distance=Point.CalculateDistance(destinationPoint, stations.get(i).getLocation());
			System.out.println("Distance of station "+i+" to the destination point= "+ distance);
			if (distance <minDistance && stations.get(i).getFreeSlots()>0 ) {
				indexDestinationStation=i;
				minDistance=distance;
			}
		}
		System.out.println("");
		System.out.println("Minimum distance (Destination Station with free slots= "+indexDestinationStation+")= "+minDistance);
		System.out.println("");
		
		RidePlanner ridePlanner=new fastest_path(BicycleType.ELECTRICAL);
		Ride ride= new Ride(user, sourcePoint ,destinationPoint,ridePlanner, stations);
		Station s1=ride.getSourceStation();
		Station s2=ride.getDestinationStation();
		System.out.println("Source and destination station given by the planner:");
		System.out.println("");
		System.out.println("Source Station= "+ s1);
		System.out.println("Destination Station= "+ s2);
		assertTrue(s1.getID()==indexSourceStation);
		assertTrue(s2.getID()==indexDestinationStation);
		System.out.println("");
		System.out.println("TEST 4 ===> OK");
		System.out.println("");
		
	}
	
}
