package JUnitTesters;

import static org.junit.jupiter.api.Assertions.*;
import mainClasses.*;
import otherClasses.*;
import classFactory.*;

import org.junit.jupiter.api.Test;

/**
 * We test the creation of stations through the StationFactory class.
 * @author Diallo
 *
 */
class StationFactoryTester {
	
    /**
     * We check if the created station is of the correct type and has the correct ID.
     */
	@Test
	void test() {
		System.out.println("");
		System.out.println("******************************************************************************");
		System.out.println("*************************** Station Factory Tester ***************************");
		System.out.println("******************************************************************************");
		System.out.println("");
		Station.n=0;
		StationFactory stationFactory=new StationFactory();
		Station s1=stationFactory.createStation(StationType.PLUS, StationState.ON_SERVICE, 10, new Point(48.8,2.1));
		Station s2=stationFactory.createStation(StationType.STANDARD, StationState.ON_SERVICE, 10, new Point(48.7,2.1));
		Station s3=stationFactory.createStation(StationType.PLUS, StationState.OFFLINE, 10, new Point(48.8,2.2));
		Station s4=stationFactory.createStation(StationType.STANDARD, StationState.OFFLINE, 10, new Point(48.7,2.0));
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);

		assertTrue(s1 instanceof StationPlus);
		assertTrue(s2 instanceof StationStandard);
		assertTrue(s3 instanceof StationPlus);
		assertTrue(s4 instanceof StationStandard);
		assertTrue(s1.getID()==0);
		assertTrue(s2.getID()==1);
		assertTrue(s3.getID()==2);
		assertTrue(s4.getID()==3);
		System.out.println("");
		System.out.println("TEST ===> OK");
		System.out.println("");
		
	}

}
