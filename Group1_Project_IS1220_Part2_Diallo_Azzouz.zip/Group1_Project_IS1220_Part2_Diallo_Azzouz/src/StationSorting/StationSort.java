package StationSorting;

import java.util.ArrayList;

import mainClasses.Station;

/**
 * An interface to sort the station with different sorting strategy: Use of a strategy pattern
 * @author Azzouz
 *
 */
public interface StationSort {
	/**
	 * Sorts a list of station with a sorting strategy
	 * @param stations: the list of stations to be sorted
	 */
	void sort(ArrayList<Station> stations);

}
