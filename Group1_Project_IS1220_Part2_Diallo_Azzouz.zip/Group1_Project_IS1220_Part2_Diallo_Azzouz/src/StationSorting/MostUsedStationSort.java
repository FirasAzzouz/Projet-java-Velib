package StationSorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import mainClasses.Station;

/**
 * A class that is used to sort the stations with respect to the number of rents and returns of bicycles (in descending order).
 * @author Azzouz
 *
 */
public class MostUsedStationSort implements StationSort{
	
	/**
	 * Sorts the stations with respect to the number of rents and returns of bicycles (in descending order).
	 */
	@Override
	public void sort(ArrayList<Station> stations) {
		MostUsedStationComparator comp=new MostUsedStationComparator();
		Collections.sort(stations,comp);
		
	}
	
	/**
	 * A nested class that allows to define a comparator for the stations that orders them according to number of rents and returns.
	 * @author Azzouz
	 *
	 */
	public class MostUsedStationComparator implements Comparator<Station>{

		@Override
		public int compare(Station station1, Station station2) {
			int s1=station1.getStationBalance().getNumRentsOperations()+station1.getStationBalance().getNumReturnsOperations();
			int s2=station2.getStationBalance().getNumRentsOperations()+station2.getStationBalance().getNumReturnsOperations();
			return s1-s2;
		}

	}
	 

}
