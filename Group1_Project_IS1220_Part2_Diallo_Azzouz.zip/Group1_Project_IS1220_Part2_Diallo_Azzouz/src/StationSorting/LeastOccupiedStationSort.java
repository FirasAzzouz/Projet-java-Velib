package StationSorting;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import mainClasses.Station;

/**
 * A class that is used to sort the stations with respect to their average occupation rate (in ascending order)
 * @author Azzouz
 *
 */
public class LeastOccupiedStationSort implements StationSort{
	
	//Two parameters to define the time window in which the average occupation rate is computed
	private Timestamp ts;
	private Timestamp te;

	/**
	 * Constructor that fixes the time window in which the average occupation rate is computed.
	 * @param ts: starting date
	 * @param te: ending date
	 */
	public LeastOccupiedStationSort(Timestamp ts, Timestamp te) {
		super();
		this.ts = ts;
		this.te = te;
	}
	
	/**
	 * Sorts the stations with respect to the average occupation rate in the ascending order.
	 */
	@Override
	public void sort(ArrayList<Station> stations) {
		LeastOccupiedStationComparator comp=new LeastOccupiedStationComparator();
		Collections.sort(stations,comp);
	}
	
	/**
	 * A nested class that allows to define a comparator for the stations that orders them according to their average occupation 
	 * rate.
	 * @author Azzouz
	 *
	 */
    public class LeastOccupiedStationComparator implements Comparator<Station> {
    	
		@Override
		public int compare(Station station1, Station station2) {
			double s1=station1.getStationBalance().AverageRateOccupation(ts, te);
			double s2=station2.getStationBalance().AverageRateOccupation(ts, te);
			if (s1>s2) {
				return -1;
			}
			if (s1<s2) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
	
	

}

	
