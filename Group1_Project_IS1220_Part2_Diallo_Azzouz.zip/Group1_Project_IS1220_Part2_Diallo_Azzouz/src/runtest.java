import java.io.File;

public class runtest {
	
	public static void main(String[] args) {
		File f=new File(args[0]);
		System.out.println(f);
	}

}