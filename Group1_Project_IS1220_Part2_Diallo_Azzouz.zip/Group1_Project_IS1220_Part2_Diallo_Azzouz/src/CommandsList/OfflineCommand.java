package CommandsList;
import CLUI.CommandExecution; 
import java.util.List;
import java.util.Map;


import mainClasses.*;
import otherClasses.StationState;
/**
 * Class that contain a method to turn a station offline.
 * @author Azzouz
 *
 */
public class OfflineCommand implements CommandExecution{
	/**
	 * Turns a station with a certain ID in a velib network offline.
	 * @param arguments: contains the velib network name (1st argument) and the station ID (2nd argument)
	 * @param myVelibSystems myVelibSystems: a hashmap containing the velib networks mapped to their names
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2) {
			String sysName = null;
			int stationId;
			try {
				sysName=(String)arguments.get(0);
				stationId=(int)(double)arguments.get(1);
				MyVelib myVelib=myVelibSystems.get(sysName);
				Station station=myVelib.getStationID(stationId);
				System.out.println("");
				System.out.println("Station "+stationId+" in velib network "+sysName+" has been set OFFLINE");
				station.setState(StationState.OFFLINE);
				System.out.println("");
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch (NullPointerException e) {
				System.out.println("No Velib system with the given name, or no station with the given ID");
			}
		}
		else {
			System.out.println("Error: OFFLINE can only take 2 arguments");
		}
	}
}
