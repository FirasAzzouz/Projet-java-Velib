package CommandsList;
import CLUI.CommandExecution;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import mainClasses.*;
import StationSorting.*;
/**
 * A class that contains a method to execute the command sortStation
 * @author Azzouz
 *
 */
public class SortStationCommand implements CommandExecution{
	String sysName;
	MyVelib myVelib;
	String sortPolicy;
	StationSort sortStrategy;
	ArrayList<Station> stations;
	Timestamp ts;
	Timestamp te;
	/**
	 * Executes the command sortStation
	 * @param arguments: (network name, sortPolicy) or (network name, sortPolicy,starting date, ending date)
	 * @param myVelibSystems
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2 || arguments.size()==4) {
			try {
				sysName=(String)arguments.get(0);
				sortPolicy=(String)arguments.get(1);
				myVelib=myVelibSystems.get(sysName);
				stations=myVelib.getStations();
				if (sortPolicy.equalsIgnoreCase("LeastOccupiedStation")) {
					ts=Timestamp.valueOf((String)arguments.get(2));
					te=Timestamp.valueOf((String)arguments.get(3));
					sortStrategy=new LeastOccupiedStationSort(ts,te);
				}
				else if (sortPolicy.equalsIgnoreCase("MostUsedStation")) {
					sortStrategy=new MostUsedStationSort();
				}
				sortStrategy.sort(stations);
				System.out.println("Stations are sorted using the "+ sortPolicy+ " policy.");
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch(NullPointerException e) {
				System.out.println("The specified network or sorting Policy are not found in the memory");
			}
		}
		else {
			System.out.println("Error: sortStation can only take 2 or 4 arguments.");
		}
	}

}
