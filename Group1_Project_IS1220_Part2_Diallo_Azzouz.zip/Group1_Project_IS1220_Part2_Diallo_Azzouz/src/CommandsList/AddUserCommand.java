package CommandsList;

import java.util.List;
import java.util.Map;

import classFactory.CardFactory;
import mainClasses.Card;
import mainClasses.MyVelib;
import mainClasses.User;
/**
 * Represents the user command and contains the proper method with which it's executed.
 * @author Azzouz
 *
 */
public class AddUserCommand {
	/**
	 * The method to execute an addUser command
	 * @param arguments: arguments entered by the user 
	 * @param myVelibSystems: the velib systems in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==3) {
			String sysName = null;
			User user=null;
			try {
				String userName=(String)arguments.get(0);
				String cardType=(String)arguments.get(1);
				sysName=(String)arguments.get(2);
				CardFactory cardFactory=new CardFactory();
				Card card=cardFactory.createCard(cardType);
				user=new User(userName,null,card);
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			try {
				myVelibSystems.get(sysName).addUser(user);
				System.out.println(myVelibSystems.get(sysName).getUsers());
				
			}
			catch (Exception e) {
				System.out.println("No Velib system with the given name");
			}
		}
		else {
			System.out.println("Error: addUser can only take 3 arguments");
		}
	}
}
