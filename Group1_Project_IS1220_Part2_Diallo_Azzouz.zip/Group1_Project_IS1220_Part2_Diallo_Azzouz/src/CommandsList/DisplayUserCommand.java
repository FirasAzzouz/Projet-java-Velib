package CommandsList;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import CLUI.CommandExecution;
import mainClasses.*;
import StatsComputing.*;
/**
 * A class that contains a method to display the user statistics
 * @author Azzouz
 *
 */
public class DisplayUserCommand implements CommandExecution{
	int stationID;
	String sysName;
	MyVelib myVelib;
	int userID;
	User user;
	UserBalance userBalance;
	/**
	 * Displays the statistics of a user
	 * @param arguments: (network name and user ID) 
	 * @param myVelibSystems: the velib networks in memory
	 */
	@SuppressWarnings("rawtypes")
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2) {
			try {
				userID=(int)(double)arguments.get(1);
				Iterator iter=myVelibSystems.entrySet().iterator();
				while(iter.hasNext()) {
					Map.Entry mapElement=(Map.Entry)iter.next();
					myVelib = (MyVelib)mapElement.getValue();
					user=myVelib.getUserID(userID);
					if (user!=null) {
						break;
					}
				}
				userBalance=user.getUserBalance();
				System.out.println("");
				System.out.println(userBalance);
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch(NullPointerException e) {
				System.out.println("The specified network or user are not found in the memory");
			}
		}
		else {
			System.out.println("Error: displayUser command only takes 2 arguments.");
		}
	}

}
