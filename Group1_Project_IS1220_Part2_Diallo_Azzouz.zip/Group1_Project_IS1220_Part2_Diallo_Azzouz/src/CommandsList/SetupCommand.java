package CommandsList;
import CLUI.CommandExecution; 
import java.util.List;
import java.util.Map;

import mainClasses.MyVelib;
/**
 * Represents the setup command and contains the proper method with which it's executed.
 * @author Azzouz
 *
 */
public class SetupCommand implements CommandExecution{
	/**
	 * The method to execute a setup command
	 * @param arguments: arguments entered by the user 
	 * @param myVelibSystems: the velib systems in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		//First Defintion of setup
		if (arguments.size()==1) {
			int N=10;
			int M=100;
			int bicyclePercentage=75;
			int electricalPercentage=30;
			
			MyVelib myVelib=new MyVelib(N,M,bicyclePercentage,electricalPercentage);
			String name=null;
			try {
				name=(String)arguments.get(0);
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				System.out.println("Setup of network "+name+" ============> successful");
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}	
		}
		//Second Defintion of setup
		else if (arguments.size()==5) {
			String name=null;
			int N=0;
			int nSlots=0;
			double s=0;
			int nBikes=0;
			try {
				name=(String) arguments.get(0);
				N=(int)(double) arguments.get(1);
				nSlots=(int)(double)arguments.get(2);
				s=(double)arguments.get(3);
				nBikes=(int)(double)arguments.get(4);
				MyVelib myVelib=new MyVelib(N,N*nSlots,(nBikes*100.0)/(nSlots*N),30);
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				System.out.println("Setup of network "+name+" ============> successful");
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
		}
		else {
			System.out.println("Error: setup can only take 1 or 5 arguments");
		}
		//System.out.println("Number of myVelib systems in memory= "+myVelibSystems.size());
	}
}
