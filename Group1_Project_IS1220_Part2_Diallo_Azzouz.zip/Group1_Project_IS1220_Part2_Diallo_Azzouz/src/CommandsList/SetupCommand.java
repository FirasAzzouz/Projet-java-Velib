package CommandsList;
import CLUI.CommandExecution; 
import java.util.List;
import java.util.Map;

import mainClasses.MyVelib;
import otherClasses.Point;
/**
 * Represents the setup command and contains the proper method with which it's executed.
 * @author Azzouz
 *
 */
public class SetupCommand implements CommandExecution{
	/**
	 * The method to execute a setup command
	 * @param arguments: arguments entered by the user 
	 * @param myVelibSystems: the velib systems in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		//First Defintion of setup
		if (arguments.size()==1) {
			int N=10;
			int M=100;
			int bicyclePercentage=75;
			int electricalPercentage=30;
			
			MyVelib myVelib=new MyVelib(N,M,bicyclePercentage,electricalPercentage);
			String name=null;
			try {
				name=(String)arguments.get(0);
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				System.out.println("Setup of network "+name+" ============> successful");
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}	
		}
		//Second Defintion of setup
		else if (arguments.size()==5 || arguments.size()==6) {
			String name=null;
			int N=0;
			int nSlots=0;
			double s=10;
			int nBikes=0;
			String shape="";
			MyVelib myVelib;
			try {
				name=(String) arguments.get(0);
				N=(int)(double) arguments.get(1);
				nSlots=(int)(double)arguments.get(2);
				s=(double)arguments.get(3);
				nBikes=(int)(double)arguments.get(4);
				if (arguments.size()==6) {
					shape=(String)arguments.get(5);
					myVelib=new MyVelib(N,N*nSlots,(nBikes*100.0)/(nSlots*N),30,s,new Point(48.5,2.1),shape);
				}
				else {
					//MyVelib myVelib=new MyVelib(N,N*nSlots,(nBikes*100.0)/(nSlots*N),30);
					myVelib=new MyVelib(N,N*nSlots,(nBikes*100.0)/(nSlots*N),30,s,new Point(48.5,2.1),"circle");
				}
				myVelib.setName(name);
				myVelibSystems.put(name,myVelib);
				System.out.println("Setup of network "+name+" ============> successful");
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch(NullPointerException e) {
				System.out.println("The shape is not recognized");
			}
		}
		else {
			System.out.println("Error: setup can only take 1, 5 or 6 arguments");
		}
		//System.out.println("Number of myVelib systems in memory= "+myVelibSystems.size());
	}
}
