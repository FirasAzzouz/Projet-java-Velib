package CommandsList;
import CLUI.CommandExecution;
import java.util.List;
import java.util.Map;

import mainClasses.MyVelib;
import otherClasses.StationState;
/**
 * Class that contain a method to turn a station offline.
 * @author Azzouz
 *
 */
public class OnlineCommand implements CommandExecution{
	/**
	 * Turns a station with a certain ID in a velib network offline.
	 * @param arguments: contains the velib network name (1st argument) and the station ID (2nd argument)
	 * @param myVelibSystems: a hashmap containing the velib networks mapped to their names
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2) {
			String sysName = null;
			int stationId;
			try {
				sysName=(String)arguments.get(0);
				stationId=(int)(double)arguments.get(1);
				MyVelib myVelib=myVelibSystems.get(sysName);
				myVelib.getStationID(stationId).setState(StationState.ON_SERVICE);
				System.out.println("Station "+stationId+" in velib network "+sysName+" has been set ONLINE");
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch (NullPointerException e) {
				System.out.println("No Velib system with the given name, or no station with the given ID");
			}
		}
		else {
			System.out.println("Error: ONLINE can only take 2 arguments");
		}
	}

}
