package CommandsList;
import mainClasses.*;
import java.util.List;
import java.util.Map;

import CLUI.CommandExecution;
import RidePlanning.Ride;
import classFactory.*;
import otherClasses.*;
/**
 * A class that contains a method to execute the planRide command
 * @author Azzouz
 *
 */
public class PlanRideCommand implements CommandExecution{
	private String sysName;
	private int userID;
	private Point sourcePoint;
	private Point destinationPoint;
	private String rideStrategy;
	private String bicycleType;
	private MyVelib myVelib;
	private User user;
	private Ride ride;
	private RideFactory rideFactory;
	/**
	 * A method to execute the planRide command
	 * @param arguments: arguments entered by the user
	 * @param myVelibSystems: the velib networks in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==8) {
			try {
				sysName=(String)arguments.get(0);
				userID=(int)(double)arguments.get(1);
				sourcePoint=new Point((double)arguments.get(2),(double)arguments.get(3));
				destinationPoint=new Point((double)arguments.get(4),(double)arguments.get(5));
				rideStrategy=(String)arguments.get(6);
				bicycleType=(String)arguments.get(7);
				myVelib=myVelibSystems.get(sysName);
				user=myVelib.getUserID(userID);
				rideFactory=new RideFactory();
				ride=rideFactory.createRide(user, sourcePoint, destinationPoint, rideStrategy, bicycleType, myVelib.getStations());
				System.out.println("");
				System.out.println("User "+user.getID()+ " plans a ride from "+sourcePoint+ " to "+destinationPoint);
				System.out.println("Ride Strategy= "+rideStrategy);
				System.out.println("Bicycle type= "+bicycleType);
				System.out.println("Optimal stations Calculated: ");
				System.out.println("Source station= "+ride.getSourceStation());
				System.out.println("Destination station= "+ride.getDestinationStation());
				System.out.println("");
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch (NullPointerException e) {
				System.out.println("Error: Specified arguments are not recognized by the system.");
			}
		}
		else {
			System.out.println("Error: planRide can only take 8 arguments");
		}
	}
}
