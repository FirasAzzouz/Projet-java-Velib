package CommandsList;
import CLUI.CommandExecution;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import mainClasses.*;
import otherClasses.SlotState;
/**
 * Class containing a method to return a bike by specifing the user Id and the station Id (and the return date).
 * @author Azzouz
 *
 */
public class ReturnBikeCommand implements CommandExecution{
	private int userId;
	private int stationId;
	private User user;
	private MyVelib myVelib;
	private Station station;
	private String time;
	private Timestamp returnDate;
	private ParkingSlot parkingSlot;
	/**
	 * a method that looks for a user with the specified ID and does the return operation.
	 * @param arguments: contains the arguments for the returnBike command
	 * @param myVelibSystems: the velib systems in memory
	 */
	@SuppressWarnings("rawtypes")
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2 || arguments.size()==4) {
			try {
				userId=(int)(double)arguments.get(0);
				stationId=(int)(double)arguments.get(1);
				if (arguments.size()==4) {
					time=(String)arguments.get(2)+" "+(String)arguments.get(3);
					returnDate=Timestamp.valueOf(time);
				}
				Iterator iter=myVelibSystems.entrySet().iterator();
				while(iter.hasNext()) {
					Map.Entry mapElement=(Map.Entry)iter.next();
					myVelib = (MyVelib)mapElement.getValue();
					user=myVelib.getUserID(userId);
					if (user!=null) {
						break;
					}
				}
				station=myVelib.getStationID(stationId);
				parkingSlot=station.findSlot(SlotState.FREE);
				Bicycle bicycle=user.getBicycle();
				user.returnBicycle(parkingSlot,returnDate);
				if (user.getBicycle()==null) {
					if (arguments.size()==2) {
						System.out.println("User "+userId+ " returned "+bicycle+" to the parking slot "+parkingSlot.getID()+ " in station "+ station.getID()+".");
					}
					else if (arguments.size()==4){
						System.out.println("User "+userId+ " returned "+bicycle+" to the parking slot "+parkingSlot.getID()+ " in station "+ station.getID()+" at "+time);
					}
				}
			}
			catch (ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch (NullPointerException e) {
				System.out.println("Error: the user or the station are not in the system.");
			}
		}
		else {
			System.out.println("Error: RETURNBIKE can only accept 2 or 4 arguments: (the user ID and the station ID) or (the user Id, the station ID, the return date and the return time.");
		}
	}

}
