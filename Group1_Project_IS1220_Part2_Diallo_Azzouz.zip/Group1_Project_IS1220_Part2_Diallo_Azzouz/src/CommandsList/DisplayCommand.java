package CommandsList;
import java.util.List;
import java.util.Map;

import mainClasses.*;
import CLUI.CommandExecution;
/**
 * A class that contains a method to execute the display Command
 * @author Azzouz
 *
 */
public class DisplayCommand implements CommandExecution {
	String sysName;
	MyVelib myVelib;
	List<Station> stations;
	List<User> users;
	/**
	 * A method to execute the display command
	 * @param arguments: (networkName)
	 * @param myVelibSystems: the velib networks in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==1) {
			try {
				sysName=(String)arguments.get(0);
				myVelib=myVelibSystems.get(sysName);
				stations=myVelib.getStations();
				users=myVelib.getUsers();
				System.out.println("");
				System.out.println("********************************MyVelibNetwork: "+ sysName +"****************************");
				System.out.println("");
				System.out.println("*************************************Stations********************************************");
				System.out.println("");
				for (Station station:stations) {
					System.out.println("******************************Station "+ station.getID()+"****************************");
					System.out.println(station);
					System.out.println("Parking slots of station "+station.getID());
					for (ParkingSlot parkingSlot:station.getParkingSlots()) {
						System.out.println(parkingSlot);
					}
				}
				System.out.println("");
				System.out.println("*************************************Stations********************************************");
				for (User user:users) {
					System.out.println(user);
				}
				System.out.println("");
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch(NullPointerException e) {
				System.out.println("The specified network is not found in the memory");
			}
		}
		else {
			System.out.println("Display commmand can only take 1 argument");
		}
	}

}
