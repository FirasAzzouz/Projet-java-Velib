package CommandsList;
import CLUI.CommandExecution; 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;

import CLUI.CommandInterpreter;
import mainClasses.*;
/**
 * A class containing the method to read and execute a script (a text file) with many commands
 * @author firas
 *
 */
public class RunTestCommand implements CommandExecution{
	/**
	 * Reads a text file and executes the commands.
	 * @param arguments: a list which should contain one element: the name of the text file
	 * @param myVelibSystems: Velib Systems in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==1) {
			try {
				String inputFilename=(String)arguments.get(0);
				File inputFile = new File(inputFilename);
				BufferedReader br = new BufferedReader(new FileReader(inputFile)); 
				String str; 
				CommandInterpreter i = new CommandInterpreter();
				String outputFilename=inputFilename.substring(0,inputFilename.length()-4)+"output.txt";
				PrintStream fileOut = new PrintStream(outputFilename);
			    System.setOut(fileOut);
				while ((str = br.readLine()) != null) {
					i.runCommand(str);
				}
				br.close();
			}
			catch(FileNotFoundException e) {System.out.println("File Not Found: check the file name or location");}
			catch(IOException e) {System.out.println("Problem reading the file");}
		}
	}
}
