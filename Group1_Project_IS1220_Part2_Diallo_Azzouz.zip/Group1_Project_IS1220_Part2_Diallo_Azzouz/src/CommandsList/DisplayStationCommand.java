package CommandsList;

import java.sql.Timestamp; 
import java.util.List;
import java.util.Map;

import mainClasses.*;
import StatsComputing.*;
import CLUI.CommandExecution;
/**
 * A class that contains a method to display the station statistics
 * @author Azzouz
 *
 */
public class DisplayStationCommand implements CommandExecution{
	int stationID;
	String sysName;
	MyVelib myVelib;
	Station station;
	StationBalance stationBalance;
	Timestamp ts;
	Timestamp te;
	/**
	 * Displays the statistics of a station
	 * @param arguments: (network name and station ID) or (network name, station ID, starting date and ending date)
	 * @param myVelibSystems: the velib networks in memory
	 */
	public void exec(List<Object> arguments,Map<String,MyVelib> myVelibSystems) {
		if (arguments.size()==2 || arguments.size()==6) {
			try {
				sysName=(String)arguments.get(0);
				myVelib=myVelibSystems.get(sysName);
				stationID=(int)(double)arguments.get(1);
				station=myVelib.getStationID(stationID);
				if (arguments.size()==2) {
					stationBalance=new StationBalance(station);
				}
				else {
					ts=Timestamp.valueOf((String)arguments.get(2)+" "+(String)arguments.get(3));
					te=Timestamp.valueOf((String)arguments.get(4)+" "+(String)arguments.get(5));
					stationBalance=new StationBalance(station,ts,te);
					System.out.println("");
					System.out.println(station);
					System.out.println(stationBalance);
				}
			}
			catch(ClassCastException e) {
				System.out.println("Type Mismatch");
			}
			catch(NullPointerException e) {
				System.out.println("The specified network or station are not found in the memory");
			}
		}
		else {
			System.out.println("Error: displayStation command takes only 2 or 6 arguments.");
		}
	}
}
