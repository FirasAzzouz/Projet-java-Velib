package mainClasses;

/**
 * Represents a  VMax Card.
 * Is used to compute the cost.
 * @author Azzouz
 *
 */
public class VmaxCard extends Card {
	
    /**
     * Creates a VMax card.
     */
	public VmaxCard() {
		super();
	}
	@Override
	public String toString() {
		return "VMaxCard [TimeCredit= "+ getTimeCredit()+"]";
	}	
	
}
