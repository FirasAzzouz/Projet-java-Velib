package mainClasses;

import CostComputing.Visitor;
import otherClasses.BicycleType;

/**
 * Represents a mechanical bicycle.
 * Extends Bicycle which implements Visitable.
 * Is used to compute the cost
 * @author Azzouz
 *
 */
public class MechanicalBicycle extends Bicycle{
	/**
     * creates a mechanical bicycle and sets its type to MECHANICAL
     */
	public MechanicalBicycle() {
		super();
		this.setType(BicycleType.MECHANICAL);
	}
	@Override
	public String toString() {
		return "MechanicalBicycle [ID=" + this.getID()+"]";
	}
	public double accept(Visitor visitor) {
		return visitor.visit(this);
	}
}
