package mainClasses;

import CostComputing.Visitor;
import otherClasses.BicycleType;

/**
 * Represents an electrical bicycle.
 * Extends Bicycle which implements Visitable.
 * Is used to compute the cost.
 * @author Azzouz
 *
 */
public class ElectricalBicycle extends Bicycle {
    /**
     * creates an electrical bicycle and sets its type to ELECTRICAL
     */
	public ElectricalBicycle() {
		super();
		this.setType(BicycleType.ELECTRICAL);
	}
	@Override
	public String toString() {
		return "ElectricalBicycle [ID=" + this.getID()+"]";
	}
	public double accept(Visitor visitor) {
		return visitor.visit(this);
	}
}
