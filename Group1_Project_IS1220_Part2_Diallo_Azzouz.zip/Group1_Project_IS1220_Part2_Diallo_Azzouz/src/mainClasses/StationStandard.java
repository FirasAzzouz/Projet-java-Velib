package mainClasses;

import otherClasses.*;

/**
 * Represents Standard stations
 * @author Azzouz
 *
 */
public class StationStandard extends Station {
	/**
	 * Creates a standard station with a certain number of slots at a certain location with a given state
	 * @param state: state of the station
	 * @param nSlots: number of slots 
	 * @param location: location of the station
	 */
	public StationStandard(StationState state, int nSlots, Point location) {
		super(state, nSlots, location);
	}
	@Override
	public String toString() {
		return "StandardStation [ID=" + getID() + ", nSlots=" + getnSlots() + ", Free slots="+getFreeSlots()+", Occupied slots="+getOccupiedSlots()+", state=" + getState() + ", location=" + getLocation() + "]";
	}
}
