package mainClasses;


import otherClasses.*;    
import RidePlanning.*;
import StatsComputing.UserBalance;


import java.sql.Timestamp;


/**
 * Represents the main features of a user and contains methods that allow to rent a bicycle and to return it
 * @author Azzouz
 */
public class User {
	private String name; // user name
	private int ID; // user ID
	private Point position; // user position: latitude and longitude
	private Card card; // user card
	private String notification; // notification sent to the user. Updated if some incident occurs during the ride
	private Bicycle bicycle; // bicycle rented to the user. Null if the user is not using the bicycle
	private Ride ride; // ride of the user. Null if the user did not create one
	private static int n; // allows to define different IDs for the users
	private UserBalance userBalance; // represents the user balance
	
	/**
	 * Allows to create a user with an ID different from those of the other users
	 * @param name : user name
	 * @param position: user position (latitude and longitude)
	 * @param card: user card
	 */
	public User(String name, Point position,Card card) {
		super();
		this.ID=n;
		this.name = name;
		this.position = position;
		this.card=card;
		card.setOwner(this);
		this.bicycle=null;
		this.userBalance=new UserBalance(this);
		n++;
	}
	
	/**
	 * Allows to rent a bicycle from a parking slot at a certain date. Creates an object ride if it's not already instantiated.
	 * Sets different elements using class Ride like the rented bicycle and the rental date. Increments the number of rents of 
	 * the parking slot.
	 * @param parkingSlot: parking slot in which the bicycle is found
	 * @param rentalDate: the date at which the bicycle is rented
	 */
	
	public void rentBicycle(ParkingSlot parkingSlot, Timestamp rentalDate) {
		if (parkingSlot.getStation().getState()==StationState.ON_SERVICE) {
			if (parkingSlot.getState()==SlotState.OCCUPIED){
				if (ride==null) {
					this.ride=new Ride(this,parkingSlot.getStation());
				}
				this.setBicycle(parkingSlot.getBicycle(),rentalDate);
				parkingSlot.incrementNumRents();
				this.ride.setBicycle(this.bicycle);
				this.ride.setRentalDate(rentalDate);
			}
			else {
				System.out.println("There's no available bicycle in the parking slot.");
			}
		}
		else {
			System.out.println("Can't rent bicycle: the station is not on service");
		}
		
	}
	
	/**
	 * Allows to return a bicycle to a parking slot at a certain date. Uses class Ride to compute the cost and set other elements
	 * like the duration, the return date and the destination station. Increments the number of returns of the parking slot.
	 * Adds 5 minutes to the user's time credit if the drop station is a plus station. 
	 * @param parkingSlot: the parking slot to which the bicycle is rented
	 * @param returnDate: the date at which the bicycle is returned
	 */
	public void returnBicycle(ParkingSlot parkingSlot,Timestamp returnDate) {
		if (parkingSlot.getStation().getState()==StationState.ON_SERVICE) {
			if (ride!=null) {
				ride.setDestinationStation(parkingSlot.getStation());
				ride.setReturnDate(returnDate);
				if (returnDate!=null) {
					ride.setDuration();
					ride.setCost();
				}
				ride.setRideState(RideState.FINISHED);
			}
			this.bicycle.setParkingSlot(parkingSlot, returnDate);
			parkingSlot.incrementNumReturns();
			this.bicycle=null;
			if ((this.getCard() instanceof VlibreCard) || (this.getCard() instanceof VmaxCard)) {
				if (parkingSlot.getStation() instanceof StationPlus) {
					this.getCard().addTimeCredit(5);
					ride.setTimeCreditAdded(5);
				}
			}
			userBalance.updateUserBalance(ride);
		}
		else {
			System.out.println("Can't return bicycle: the station is not on service");
		}
		
	}
	
	/**
	 * sets the user bicycle with a rental date so that it can be used in computing the station balance.
	 * @param bicycle: the rented bicycle
	 * @param time: the rental date
	 */
	public void setBicycle(Bicycle bicycle,Timestamp time) {
		this.bicycle = bicycle;
		bicycle.setBicycleUser(this,time);
	}
	
	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public Point getPosition() {
		return position;
	}
	public void setPosition(Point position) {
		this.position = position;
	}
	public Bicycle getBicycle() {
		return bicycle;
	}
	
	public void setBicycle(Bicycle bicycle) {
		this.bicycle = bicycle;
		bicycle.setBicycleUser(this);
	}
		
	public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
		System.out.println(notification);
	}

	public Ride getRide() {
		return ride;
	}

	public void setRide(Ride ride) {
		this.ride = ride;
	}

	public UserBalance getUserBalance() {
		return userBalance;
	}

	public void setUserBalance(UserBalance userBalance) {
		this.userBalance = userBalance;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", ID=" + ID + ", card=" + card + "]";
	}
	
}

