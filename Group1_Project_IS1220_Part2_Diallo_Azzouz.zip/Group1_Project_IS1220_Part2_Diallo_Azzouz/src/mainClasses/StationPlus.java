package mainClasses;

import otherClasses.*;

/**
 * Represents Plus stations
 * @author Azzouz
 * 
 */
public class StationPlus extends Station{
	/**
	 * Creates a plus station with a certain number of slots at a certain location with a given state
	 * @param state: state of the station
	 * @param nSlots: number of slots 
	 * @param location: location of the station
	 */
	public StationPlus(StationState state, int nSlots, Point location) {
		super(state, nSlots, location);
	}
	
	@Override
	public String toString() {
		return "PlusStation [ID=" + getID() + ", nSlots=" + getnSlots() + ", Free slots="+getFreeSlots()+", Occupied slots="+getOccupiedSlots()+", state=" + getState() + ", location=" + getLocation() + "]";
	}
	
}

