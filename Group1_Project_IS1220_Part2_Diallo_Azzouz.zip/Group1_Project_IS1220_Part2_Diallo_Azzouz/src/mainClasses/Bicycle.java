package mainClasses;
import CostComputing.*;
import java.sql.Timestamp;

import otherClasses.*;


/**
 * Represents the main features of a bicycle and allows to change its parking slot and its user.
 * Implements Visitable in order to compute the cost.
 * @author Azzouz
 *
 */
public abstract class Bicycle implements Visitable{
	private int ID; //Bicycle ID
	public static int n; //Used to define different IDs for the bicycles
	private ParkingSlot parkingSlot; //The parking slot where the bicycle is parked. Null if the bicycle is rented.
	private User bicycleUser; //User renting the bicycle 
	private BicycleType type; //Bicycle Type: Mechanical or Electrical
	
	/**
	 * Creates a bicycle with an ID different from those of the other bicycles.
	 */
	public Bicycle() {
		super();
		this.ID = n;
		n++;
	}
	
	/**
	 * sets the user of the bicycle and changes the state of the parking slot to FREE.
	 * @param bicycleUser: the user renting the bicycle
	 */
	public void setBicycleUser(User bicycleUser) {
		this.bicycleUser = bicycleUser;
		if (this.parkingSlot!=null) {
			this.getParkingSlot().setState(SlotState.FREE);
			this.parkingSlot=null;
		}
	}
	
	/**
	 * sets the user of the bicycle at a certain rental date and changes the state of the parking slot to FREE.
	 * Is used to compute the station balance.
	 * @param bicycleUser: the user renting the bicycle
	 * @param time: the rental date
	 */
	public void setBicycleUser(User bicycleUser,Timestamp time) {
		this.bicycleUser = bicycleUser;
		if (this.parkingSlot!=null) {
			this.getParkingSlot().setState(SlotState.FREE,time);
			this.parkingSlot=null;
		}
	}

	public ParkingSlot getParkingSlot() {
		return parkingSlot;
	}
	
	/**
	 * Sets the parking slot of the bicycle and changes the state of this parking slot.
	 * @param parkingSlot: the parking slot where the bicycle is dropped
	 */
	public void setParkingSlot(ParkingSlot parkingSlot) {
		if (this.parkingSlot!=null) {
			this.parkingSlot.setState(SlotState.FREE);
		}
		
		if (parkingSlot==null) {
			this.parkingSlot=null;
		}
		else if (parkingSlot.getState()==SlotState.FREE){
			parkingSlot.setBicycle(this);
			this.bicycleUser=null;
			this.parkingSlot = parkingSlot;
		}
		else {
			System.out.println("This parking slot is occupied");
		}
	}
	
	/**
	 * Sets the parking slot of the bicycle and changes the state of this parking slot at a certain date.
	 * Is used to compute the station balance.
	 * @param parkingSlot: the parking slot where the bicycle is dropped
	 * @param time: the time at which the operation is made
	 */
    public void setParkingSlot(ParkingSlot parkingSlot,Timestamp time) {
		
		if (this.parkingSlot!=null) {
			this.parkingSlot.setState(SlotState.FREE,time);
		}
		
		if (parkingSlot==null) {
			this.parkingSlot=null;
			
		}
		else if (parkingSlot.getState()==SlotState.FREE){
			parkingSlot.setBicycle(this,time);
			this.bicycleUser=null;
			this.parkingSlot = parkingSlot;
		}
		else {
			System.out.println("This parking slot is occupied");
		}
	}
    
    public User getBicycleUser() {
		return bicycleUser;
	}

	@Override
	public String toString() {
		return "Bicycle [ID=" + ID + ", parkingSlot=" + parkingSlot + "]";
	}
	
	public BicycleType getType() {
		return type;
	}

	public void setType(BicycleType type) {
		this.type = type;
	}

	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	
}
