package mainClasses;

/**
 * Represents the situation when the user does not have a Velib Card
 * Is used to compute the cost.
 * @author firas
 *
 */
public class NoCard extends Card {

	@Override
	public String toString() {
		return "CreditCard []";
	}
	
}
