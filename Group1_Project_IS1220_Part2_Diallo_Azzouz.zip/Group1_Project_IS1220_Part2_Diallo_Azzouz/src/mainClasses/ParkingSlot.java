package mainClasses;
import java.sql.Timestamp;
import java.util.ArrayList;

import RideUpdating.Observer;
import otherClasses.SlotState;

/**
 * Presents the main features of a parking slot. 
 * Contains methods to change the state of the parking slot and to compute the occupation duration. 
 * @author Azzouz
 *
 */
public class ParkingSlot {
	private int ID; //ID of the parking slot
	private Station station; //Station to which the parking slot belongs
	private SlotState state; //State of the parking slot: OCCUPIED, FREE or OUT_OF_SERVICE
	private Bicycle bicycle; //Bicycle in the parking slot. Null if the parking slot is free.
	
	private int numRents; //Total number of rents of this parking slot.
	private int numReturns; //Total number of returns to this parking slot.
	
	
	private ArrayList<Timestamp> ti=new ArrayList<Timestamp>(); //Dates at which the parking slot became OCCUPIED or OUT_OF_SERVICE
	private ArrayList<Timestamp> tj=new ArrayList<Timestamp>(); //Dates at which the parking slot became FREE.
	
    /**
     * Creates a parking slot with a certain state belonging to a station and add this parking slot to the list of parking slots 
     * of this station.
     * @param station: the station to which the parking slot belongs
     * @param state: the state of the parking slot: OCCUPIED, FREE or OUT_OF_SERVICE
     */
	public ParkingSlot(Station station, SlotState state) {
		super();
		this.ID = station.m;
		this.station = station;
		station.addParkingSlot(this);
		this.state = state;
		station.m++;
	}
	
	@Override
	public String toString() {
		return "ParkingSlot [ID=" + ID + ", stationID=" + station.getID() + ", state=" + state + "]";
	}

	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public Station getStation() {
		return station;
	}
	public void setStation(Station station) {
		this.station = station;
	}
	public SlotState getState() {
		return state;
	}
	/**
	 * Sets the state of the parking slot and changes correspondingly other variables like the bicycle in the parking slot.
	 * Notifies the observers if all the parking slot in the station become OCCUPIED.
	 * @param state: the new state of the parking slot
	 */
	public void setState(SlotState state) {
		if (state==SlotState.FREE) {
			this.bicycle=null;
			this.state=state;
		}
		else if (state==SlotState.OCCUPIED || state==SlotState.OUT_OF_ORDER) {
			this.state=state;
			if (this.station.getFreeSlots()==0) {
				this.station.notifyObservers("No more free parking slots in the destination station.");
				station.setObs(new ArrayList<Observer>());
			}
		}
	}
	/**
	 * Another implementation of setState but with another parameter allowing to store the data at which the parking slot's state
	 * changes. This allows to compute the occupation time and to use it in the calculation of the average occupation rate.
	 * @param state: the new state if the parking slot.
	 * @param time: the date at which the parking slot's state changes.
	 */
	public void setState (SlotState state, Timestamp time) {
		if ((this.state==SlotState.FREE) && ((state==SlotState.OCCUPIED)||(state==SlotState.OUT_OF_ORDER))){
			this.ti.add(time);
			
		}
		else if ((state==SlotState.FREE) && ((this.state==SlotState.OCCUPIED)||(this.state==SlotState.OUT_OF_ORDER))) {
			this.tj.add(time);
		}
		this.state=state;		
	}
	/**
	 * Computes the occupation duration inside a given window using the list of dates containing the time slots in which the parking 
	 * slot is OCCUPIED. 
	 * @param ts: starting date
	 * @param te: ending date
	 * @return occupation duration between ts and te
	 */
	public double calculateOccupationDuration(Timestamp ts, Timestamp te) {
		double deltaTime=0;
		
		ArrayList<Timestamp> ti_copy=new ArrayList<Timestamp>();
		ArrayList<Timestamp> tj_copy=new ArrayList<Timestamp>();
		
		if (ti.size()>0 && tj.size()>0){
			for (int i=0;i<ti.size();i++) {
				if ((ti.get(i).getTime()>=ts.getTime()) && (ti.get(i).getTime()<=te.getTime())) {
					ti_copy.add(ti.get(i));
				}
				if ((tj.get(i).getTime()>=ts.getTime()) && (tj.get(i).getTime()<=te.getTime())){
					tj_copy.add(tj.get(i));
				}
			}
			
			if (tj_copy.get(0).getTime()<ti_copy.get(0).getTime()) {
				ti_copy.add(0,ts);
			}
			if (tj_copy.get(tj_copy.size()-1).getTime()<ti_copy.get(ti_copy.size()-1).getTime()) {
				tj_copy.add(tj_copy.size(),te);
			}
		}
		else if (ti.size()==1 && tj.size()==0) {
			if (ti.get(0).getTime()>=ts.getTime() && ti.get(0).getTime()<=te.getTime()) {
				ti_copy.add(ti.get(0));
				tj_copy.add(te);
			}
		}
		else if (ti.size()==0 && tj.size()==1) {
			if (tj.get(0).getTime()>=ts.getTime() && tj.get(0).getTime()<=te.getTime()) {
				tj_copy.add(tj.get(0));
				ti_copy.add(ts);
			}
		}
		else if (ti.size()==0 && tj.size()==0) {
			if (this.state==SlotState.OCCUPIED || this.state==SlotState.OUT_OF_ORDER) {
				ti_copy.add(ts);
				tj_copy.add(te);
			}
			else if (this.state==SlotState.FREE) {
			}
		}
		
		if (ti_copy.size()==tj_copy.size()) {
			for (int i=0;i<ti_copy.size();i++) {
				deltaTime+=(tj_copy.get(i).getTime()-ti_copy.get(i).getTime())/(60*1000);
			}
		}
		else {
			System.out.println("Warning !");
		}
		return deltaTime;
	}

	public ArrayList<Timestamp> getTi() {
		return ti;
	}

	public void setTi(ArrayList<Timestamp> ti) {
		this.ti = ti;
	}

	public ArrayList<Timestamp> getTj() {
		return tj;
	}

	public void setTj(ArrayList<Timestamp> tj) {
		this.tj = tj;
	}

	public Bicycle getBicycle() {
		return bicycle;
	}
     
	/**
	 * Sets the bicycle parked in the parking slot and correspondingly other variables like parking slot's state.
	 * @param bicycle: bicycke parked in the parking slot
	 */
	public void setBicycle(Bicycle bicycle) {
		if (this.state==SlotState.FREE && bicycle!=null){
			this.bicycle = bicycle;
			setState(SlotState.OCCUPIED);
		}
		else if (this.state==SlotState.OCCUPIED){
			System.out.println("The parking slot already contains a bicycle.");
		}
		
	}
	
	/**
	 * Sets the bicycle parked in the parking slot and correspondingly other variables like parking slot's state.
	 * Take into account the date.
	 * @param bicycle: bicycle parked in the parking slot
	 * @param time: date at which the operation is made
	 */
	public void setBicycle(Bicycle bicycle,Timestamp time) {
		if (this.state==SlotState.FREE){
			this.bicycle = bicycle;
			setState(SlotState.OCCUPIED,time);
		}
		else {
			System.out.println("The parking slot already contains a bicycle.");
		}
		
	}

	public int getNumRents() {
		return numRents;
	}

	public void setNumRents(int numRents) {
		this.numRents = numRents;
	}

	public int getNumReturns() {
		return numReturns;
	}

	public void setNumReturns(int numReturns) {
		this.numReturns = numReturns;
	}
	
	public void incrementNumRents() {
		this.numRents+=1;
	}
	public void incrementNumReturns() {
		this.numReturns+=1;
	}
}
