package mainClasses;

import classFactory.*;     
import otherClasses.*;
import StatsComputing.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Allows to create a MyVelib system using different constructors. It contains methods that allocate states to the parking slots 
 * and fill them with bicycles from different types. Some methods allow also to show the user balance and the station balance.
 * @author Azzouz
 * 
 */

public class MyVelib {
	private String name;
	private int N;// Number of stations
	private int M;// Total number of parking slots
	private int nBicycles;// Total number of bicycles
	private Bicycle [] bicycles;// Array with all the bicycles in the system
	private double bicyclePercentage;// percentage of occupied parking slots
	private double electricalPercentage;// percentage of electrical bicycles
	private double nElectricalBicycles;// total number of electrical bicycles
	private double nMechanicalBicycles;// total number of mechanical bicycles
	
	private ArrayList<Station> stations=new ArrayList<Station>();// List with all the stations
	private ParkingSlot [] parkingSlots;// Array with all the parking slots
	private ArrayList<User> users=new ArrayList<User>();// List with all the users
	
	/**
	 * Use this constructor when the stations are already given with their positions. This allows to run some tests
	 * because you can control the location of each station. The parking slots are filled randomly with bicycles from different 
	 * types. Some parkingSlots stay free. You can control their occupation using the parameters bicyclePercentage and 
	 * electricalPercentage.
	 * @param stations: List with all the stations
	 * @param bicyclePercentage: percentage of occupied parking slots
	 * @param electricalPercentage: percentage of electrical bicycle
	 */
	public MyVelib(ArrayList<Station> stations,double bicyclePercentage, double electricalPercentage) {
		super();
		this.bicyclePercentage = bicyclePercentage;
		this.electricalPercentage = electricalPercentage;
		this.stations = stations;
		N=stations.size();
		M=getTotalSlots();
		nBicycles=(int) Math.round(M*bicyclePercentage/100);
		parkingSlots= new ParkingSlot [M];
		bicycles=new Bicycle[nBicycles];
		fillStations();
	}
	
	/**
	 * Use this constructor when you want to create a system where the stations are given at random positions (but included in a 
	 * square defined by certain latitudes and longitudes). The parking slots are filled randomly with bicycles from different 
	 * types. Some parkingSlots stay free. You can control their occupation using the parameters bicyclePercentage and 
	 * electricalPercentage.
	 * @param N: Total number of stations
	 * @param M: Total number of parking slots in the system
	 * @param bicyclePercentage: percentage of occupied parking slots
	 * @param electricalPercentage: percentage of electrical bicycles
	 */
	
	public MyVelib(int N, int M, double bicyclePercentage, double electricalPercentage) {
		this.N=N;
		this.M=M;
		this.bicyclePercentage = bicyclePercentage;
		this.electricalPercentage = electricalPercentage;
		generateRandomStations(N,M,48.7,48.9,2,2.2);
		nBicycles=(int) Math.round(M*bicyclePercentage/100);
		parkingSlots= new ParkingSlot [M];
		bicycles=new Bicycle[nBicycles];
		fillStations();
	}

	/**
	 * Adds a user to the system.
	 * @param user: user to add the list of users
	 */
	public void addUser(User user) {
		users.add(user);
	}
	/**
	 * @return Total number of parkingSlots
	 */
	public int getTotalSlots() {
		int S=0;
		for (Station station:this.stations) {
			S=S+station.getnSlots();
		}
		return S;
	}
	/**
	 * @return Total number of free parking slots
	 */
	public int getTotalFreeSlots() {
		int S=0;
		for (Station s:stations) {
			S=S+s.getFreeSlots();
		}
		return S;
	}
	/**
	 * @param bicycleType: type of bicycle which you want to count
	 * @return total number of bicycles of a certain type in the system 
	 */
	public int getTotalBicycleType(BicycleType bicycleType) {
		int c=0;
		for (Station station:stations) {
			for (ParkingSlot parkingSlot: station.getParkingSlots()) {
				if (parkingSlot.getState()==SlotState.OCCUPIED) {
					if (parkingSlot.getBicycle().getType()==bicycleType) {
						c++;
					}	
				}
			}
		}
		return c;
	}
	
	/**
	 * Allows to randomly distribute different states of the parking slots in all the stations, taking into
	 * account the specified occupation percentage.
	 * @return a list containing the state (FREE or OCCUPIED) of each parking slot .
	 */
	public List<SlotState> setParkingSlotsState() {
		List<SlotState> parkingSlotsState=new ArrayList<SlotState>();
		for (int i=0;i<(int)Math.round(bicyclePercentage*M/100);i++) {
			parkingSlotsState.add(SlotState.OCCUPIED);
		} 
		for (int i=(int)Math.round(bicyclePercentage*M/100);i<M;i++) {
			parkingSlotsState.add(SlotState.FREE);
		} 
		Collections.shuffle(parkingSlotsState);
	
		return parkingSlotsState;
	}
	
	/**
	 * Allows to randomly choose the type of each bicycle, taking into account the total number of bicycles and the percentage of 
	 * electrical bicycles.
	 * @return a list containing the type of each bicycle (MECHANICAL or ELECTRICAL)
	 */
	public List<BicycleType> setBicyclesType(){
		List<BicycleType> BicyclesType=new ArrayList<BicycleType>();
		for (int i=0;i<(int)Math.round(electricalPercentage*nBicycles/100);i++) {
			BicyclesType.add(BicycleType.ELECTRICAL);
		} 
		for (int i=(int)Math.round(electricalPercentage*nBicycles/100);i<nBicycles;i++) {
			BicyclesType.add(BicycleType.MECHANICAL);
		} 
		Collections.shuffle(BicyclesType);
		return BicyclesType;
	}
	
	/**
	 * Creates bicycles from different types. Uses the class BicycleFactory and the method setBicycleType to distribute randomly
	 * bicycles in the stations
	 * @return an array with bicycles from different types
	 */
	public Bicycle[] createBicycles(){
		BicycleFactory bicycleFactory=new BicycleFactory();
		
		List<BicycleType> bicyclesType=setBicyclesType();
		for (int i=0;i<nBicycles;i++) {
			bicycles[i]=bicycleFactory.createBicycle(bicyclesType.get(i));
		}
		return bicycles;
	}

	/**
	 * fills the stations randomly using the methods setParkingSlotsState and createBicycles, taking into account the percentage
	 * given in the constructor of MyVelib
	 */
	public void fillStations() {
		
		List<SlotState> parkingSlotsState= setParkingSlotsState();
		bicycles=createBicycles();
		
		int slotIndex=0;
		int bicycleIndex=0;
		for (Station station:this.stations) {
			for (int i=0; i<station.getnSlots();i++) {
				parkingSlots[i+slotIndex]=new ParkingSlot(station,SlotState.FREE);
				if (parkingSlotsState.get(i+slotIndex)==SlotState.OCCUPIED) {
					bicycles[bicycleIndex].setParkingSlot(parkingSlots[i+slotIndex]);
					bicycleIndex++;
				}
				
			}
			slotIndex=slotIndex+station.getnSlots();
		}	
	}
	/**
	 * Generates stations with random type (Plus or Standard) at random positions inside a square defined by latitudes and longitudes. 
	 * The method takes into consideration the total number of stations and the total number of parking slots and distributes the 
	 * number of slots for each station in a comparable way.
	 * @param N: Total number of stations
	 * @param M: Total number of parking slots
	 * @param lat1: minimal latitude
	 * @param lat2: maximal latitude
	 * @param lon1: minimal longitude
	 * @param lon2: maximal longitude
	 */
	public void generateRandomStations(int N, int M, double lat1, double lat2, double lon1, double lon2) {
		int totalSlots=0;
		for (int i=0; i<N; i++) {
			double lat=lat1+Math.random()*(lat2-lat1);
			double lon=lon1+Math.random()*(lon2-lon1);
			int nSlots=(int)Math.round((M-totalSlots)/(N-i));
			totalSlots=totalSlots+nSlots;
			double r=Math.random();
			if (r>=0.5) {
				stations.add(new StationPlus(StationState.ON_SERVICE,nSlots,new Point(lat,lon)));
			}
			else {
				stations.add(new StationStandard(StationState.ON_SERVICE,nSlots,new Point(lat,lon)));
			}
			
		}
	}
	
	/**
	 * Displays the user balance of all users. Uses the class UserBalance in the StatsComputing package.
	 */
	
	public void showUsersbalance() {
		for (User user:users) {
			System.out.println(user.getUserBalance());
		}
	}
	/**
	 * Displays the station balance of all stations between two time stamps. Uses the class StationBalance in the StatsComputing 
	 * package. 
	 * @param ts: starting time stamp
	 * @param te: ending time stamp
	 */
	public void showStationsbalance(Timestamp ts, Timestamp te) {
		System.out.println("(ts=" + ts + ", te=" + te + ")"); 
		for (Station station:stations) {
			System.out.println(new StationBalance(station,ts,te));
		}
	}
	
	public int getN() {
		return N;
	}
	public int getM() {
		return M;
	}
	public int getnBicycles() {
		return nBicycles;
	}
	public Bicycle[] getBicycles() {
		return bicycles;
	}
	public ArrayList<Station> getStations() {
		return stations;
	}
	public ParkingSlot[] getParkingSlots() {
		return parkingSlots;
	}
	public ArrayList<User> getUsers() {
		return users;
	}
	public void setStations(ArrayList<Station> stations) {
		this.stations = stations;
	}
	public void setUsers(ArrayList<User> users) {
		this.users = users;
	}

	public double getnElectricalBicycles() {
		nElectricalBicycles=getTotalBicycleType(BicycleType.ELECTRICAL);
		
		return nElectricalBicycles;
	}

	public void setnElectricalBicycles(double nElectricalBicycles) {
		this.nElectricalBicycles = nElectricalBicycles;
	}

	public double getnMechanicalBicycles() {
		nMechanicalBicycles=getTotalBicycleType(BicycleType.MECHANICAL);
		return nMechanicalBicycles;
	}

	public void setnMechanicalBicycles(double nMechanicalBicycles) {
		this.nMechanicalBicycles = nMechanicalBicycles;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
