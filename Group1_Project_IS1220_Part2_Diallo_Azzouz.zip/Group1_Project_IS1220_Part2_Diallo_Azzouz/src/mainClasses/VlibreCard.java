package mainClasses;

/**
 * Represents a  VLibre Card.
 * Is used to compute the cost.
 * @author Azzouz
 *
 */
public class VlibreCard extends Card {
    /**
     * Creates a VLibre Card.
     */
	public VlibreCard() {
		super();
	}

	@Override
	public String toString() {
		return "VLibreCard [TimeCredit= "+ getTimeCredit()+"]";
	}	
	
	

}
