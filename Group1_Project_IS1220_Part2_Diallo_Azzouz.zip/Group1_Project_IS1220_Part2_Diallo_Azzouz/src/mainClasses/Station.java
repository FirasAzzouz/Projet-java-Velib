package mainClasses;
import otherClasses.* ; 
import RideUpdating.*;
import StatsComputing.StationBalance;

import java.util.ArrayList;

/**
 * Presents the main features of a station. 
 * Implements Observable to notify the users (through the class Ride which is the observer) when an incident occurs. 
 * @author Azzouz
 *
 */
public abstract class Station implements Observable{
	private int ID; //ID of the station
	private int nSlots; //Number of parking slots in the station
	private StationState state; //State of the station: ON_SERVICE or OFFLINE
	private ArrayList<ParkingSlot> parkingSlots=new ArrayList <ParkingSlot>(); //List of the parking slots in the station
	private Point location; //Location (latitude and longitude)
	public static int n=0; 
	public int m=0;
	private ArrayList<Observer> obs=new ArrayList<Observer>() ; // List of registred observers
	private StationBalance stationBalance; //Station balance
	
	/**
	 * Creates a station with a certain number of slots at a certain location with a given state
	 * @param state: state of the station
	 * @param nSlots: number of slots 
	 * @param location: location of the station
	 */
	public Station(StationState state, int nSlots,Point location) {
		super();
		this.ID = n;
		this.state=state;
		this.nSlots = nSlots;
		this.location=location;
		
		n++;
	}
	
    /**
     * Gives the number of free slots in the station
     * @return number of free slots in the station
     */
	public int getFreeSlots() {
		int c=0;
		for (ParkingSlot p:parkingSlots) {
			if (p.getState()==SlotState.FREE) {
				c++;
			}
		}
		return c;
	}
	
	/**
     * Gives the number of occupied slots in the station
     * @return number of occupied slots in the station
     */
	public int getOccupiedSlots() {
		int c=0;
		for (ParkingSlot p:parkingSlots) {
			if (p.getState()==SlotState.OCCUPIED) {
				c++;
			}
		}
		return c;
	}
	
	
	/**
	 * Searchs a parking slot with a certain state. 
	 * @param slotState: state of the searched parking slot: OCCUPIED, FREE or OUT_OF_ORDER
	 * @return a parking slot with the specified state. Null if this parking slot does not exist.
	 */
	public ParkingSlot findSlot(SlotState slotState) {
		int i=0;
		Boolean b=(this.parkingSlots.get(i).getState()!=slotState);
		while ((i<this.nSlots) && (b)) {
			i++;
			b=(this.parkingSlots.get(i).getState()!=slotState);
		}
		if (!b) {
			return this.parkingSlots.get(i);
		}
		
		if (slotState==SlotState.OCCUPIED) {
			System.out.println("No bicycles in this station.");
		}
		else if (slotState==SlotState.FREE) {
			System.out.println("No free slots in this station.");
		}
		return null;
	}
	
	/**
	 * Finds the parking slot in this station containing the bicycle of the desired type.
	 * @param bicycleType: MECHANICAL or ELECTRICAL
	 * @return the parking slot occupied by the bicycle of type bicycleType
	 */
	public ParkingSlot findBicycle(BicycleType bicycleType) {
		int i=0;
		Boolean b1=(this.parkingSlots.get(i).getState()==SlotState.OCCUPIED);
		Boolean b2=new Boolean("False");
		if (b1) {
			b2=(this.parkingSlots.get(i).getBicycle().getType()==bicycleType);
		}
		while ((i<this.nSlots) && !(b2)) {
			i++;
			b1=(this.parkingSlots.get(i).getState()==SlotState.OCCUPIED);
			if (b1) {
				b2=(this.parkingSlots.get(i).getBicycle().getType()==bicycleType);
			}
		}
		if (b2) {
			return this.parkingSlots.get(i);
		}
		else {
			System.out.println("No bicycles of the desired type here.");
			
		}
		return null;
	}
	
	/**
	 * Gives the number of bicycles in this station of the desired type
	 * @param type: MECHANICAL or ELECTRICAl
	 * @return the number of bicycles of the desired type
	 */
	public int getNumBicycle(BicycleType type) {
		int c=0;
		for (ParkingSlot p:parkingSlots) {
			if (p.getState()==SlotState.OCCUPIED && p.getBicycle()!=null) {
				if (p.getBicycle().getType()==type) {
					c++;
				}
			}
		}
		return c;
	}
	
	/**
	 * registers an observer (Ride) to this station
	 */
	public void registerObserver(Observer o) {
		obs.add(o);
	}
	
	/**
	 * removes an observer (Ride) of this station's registration list 
	 */
	public void unregisterObserver(Observer o) {
		obs.remove(o);
	}
	/**
	 * Notifies the observers if an incident happens.
	 */
	public void notifyObservers(String notification) {
		for (Observer ob:obs) {
			ob.update(this,notification);
		}	
	}
	
	/**
	 * adds a parking slot to the list of parking slots of this station.
	 * @param parkingSlot: the parking slot to add.
	 */
	public void addParkingSlot(ParkingSlot parkingSlot) {
		parkingSlots.add(parkingSlot);
	}
	
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public int getnSlots() {
		return nSlots;
	}

	public void setnSlots(int nSlots) {
		this.nSlots = nSlots;
	}

	public StationState getState() {
		return state;
	}
	
    /**
     * Sets the state of the station. Notifies the observers if the state is offline.
     * @param state: the new state of the station: ON_SERVICE or OFFLINE
     */
	public void setState(StationState state) {
		this.state = state;
		if (state==StationState.OFFLINE){
			notifyObservers("The destination station has gone offline");
			obs=new ArrayList<Observer>();
		}	
	}
	public void setAllSlotsOccupied() {
		for (ParkingSlot p:parkingSlots) {
			if (p.getState()!=SlotState.OCCUPIED) {
				p.setState(SlotState.OCCUPIED);
			}
		}
	}
	public void setAllSlotsFree() {
		for (ParkingSlot p:parkingSlots) {
			if (p.getState()!=SlotState.FREE) {
				p.setState(SlotState.FREE);
			}
		}
	}

	public Point getLocation() {
		return location;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public ArrayList<ParkingSlot> getParkingSlots() {
		return parkingSlots;
	}

	public void setParkingSlots(ArrayList<ParkingSlot> parkingSlots) {
		this.parkingSlots = parkingSlots;
	}

	
	public ArrayList<Observer> getObs() {
		return obs;
	}

	public void setObs(ArrayList<Observer> obs) {
		this.obs = obs;
	}
	

	public StationBalance getStationBalance() {
		return stationBalance;
	}

	public void setStationBalance(StationBalance stationBalance) {
		this.stationBalance = stationBalance;
	}

	@Override
	public String toString() {
		return "Station [ID=" + ID + ", nSlots=" + nSlots + ", Free slots="+this.getFreeSlots()+", Occupied slots="+this.getOccupiedSlots()+", state=" + state + ", location=" + location + "]";
	}
}
