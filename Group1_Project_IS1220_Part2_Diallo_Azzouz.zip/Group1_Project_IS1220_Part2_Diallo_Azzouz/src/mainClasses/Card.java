package mainClasses;


/**
 * Abstract class representing the features of a card.
 * Is used to compute the cost.
 * Allows to add time credit. 
 * Extended to VlibreCard, VmaxCard and NoCard.
 * @author Azzouz
 *
 */
public abstract class Card {
	private int timeCredit; //Time credit of the user
	private User owner; //Owner of the card
    
	/**
	 * Constructor of Card
	 */
	public Card() {
		super();
	}

	public int getTimeCredit() {
		return timeCredit;
	}

	public void setTimeCredit(int timeCredit) {
		this.timeCredit = timeCredit;
	}
	
	/**
	 * Adds time credit to the card. Is used to add time credit when dropping a bicycle to a plus station.
	 * @param time: added time to the card
	 */
	public void addTimeCredit(int time) {
		this.timeCredit=this.timeCredit+time;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}
}