
package StatsComputing;

import RidePlanning.Ride;

import mainClasses.*;

/**
 * 
 * @author Diallo
 *
 */
public class UserBalance {
	
	
	/**
	 * numRides corresponds to the number of rides performed by our user 
	 * 
	 * totalTimeBike is the total time spend on a bike 
	 * 
	 * totalChargeRides corresponds to the total amount of charges
	 *  for all rides performed by our user 
	 * 
	 * timeCreditUser is the time credit earned by our user
	 */
	
	private User user;
	private int  numRides;
	private double totalTimeBike;

	private double totalChargeRides;
	
	private double timeCreditUser;

	
	public UserBalance(User user) {
		this.user=user;
	}
	
	public void updateUserBalance(Ride ride) {
		
		/**
		 * 
		 * as specified in the ride class 
		 * getDuration determines the duration of a ride 
		 * while getCost finds the cost of a ride 
		 */
		
		numRides+=1;
		totalTimeBike+=ride.getDuration();
		totalChargeRides+=ride.getCost();
		timeCreditUser+=ride.getTimeCreditAdded();
		
		
	}

	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getNumRides() {
		return numRides;
	}

	public void setNumRides(int numRides) {
		this.numRides = numRides;
	}

	public double getTotalTimeBike() {
		return totalTimeBike;
	}

	public void setTotalTimeBike(double totalTimeBike) {
		this.totalTimeBike = totalTimeBike;
	}

	public double getTotalChargeRides() {
		return totalChargeRides;
	}

	public void setTotalChargeRides(double totalChargeRides) {
		this.totalChargeRides = totalChargeRides;
	}

	public double getTimeCreditUser() {
		return timeCreditUser;
	}

	public void setTimeCreditUser(double timeCreditUser) {
		this.timeCreditUser = timeCreditUser;
	}

	@Override
	public String toString() {
		return "UserBalance [user=" + user + ", numRides=" + numRides + ", totalTimeBike=" + totalTimeBike
				+ ", totalChargeRides=" + totalChargeRides + ", timeCreditUser=" + timeCreditUser + "]";
	}

	

	
	
	
}