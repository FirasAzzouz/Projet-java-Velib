package StatsComputing;

import java.sql.Timestamp;
/**
 * 
 * @author Diallo
 * 
 */

import mainClasses.*;


public class StationBalance {
	
	/**
	 * ts and te are the specific times 
	 * as define in the project paper. We will consider the interval time (te-ts) further 
	 * to perform some computation 
	 * 
	 * numRentsOperations is the number of rental Bicycle of a station (station) 
	 * numReturnStation is the number of return Bicycle of the same station
	 * averageRateOccupation is the average rate of occupation of our station over a given time window (te-ts)
	 */
	
	Timestamp ts;
	Timestamp te;
	Station station;
	
	private int numRentsOperations;
	private int numReturnsOperations;
	private double averageRateOccupation;
	
	
	public StationBalance(Station station) {
		super();
		this.station=station;
		station.setStationBalance(this);
	}
	
	public StationBalance(Station station, Timestamp ts, Timestamp te) {
		super();
		this.station=station;
		station.setStationBalance(this);
		this.numRentsOperations=this.getNumRentsOperations();
		this.numReturnsOperations=this.getNumReturnsOperations();
		this.averageRateOccupation=this.AverageRateOccupation(ts, te);
	}

	
	
	/**
	 * our method AverageRateOccupation determines the average rate occupation . For doing so , we compute the 
	 * the occupation duration of all the parking slots of our station by using the method 
	 * "calculateOccupationDuration" during the time window (te-ts).
	 * @param ts
	 * @param te
	 * @return
	 * 
	 */
	
	
	public double AverageRateOccupation(Timestamp ts, Timestamp te) {
		
		this.ts=ts;
		this.te=te;
		
		double time = 0;
		double delta=(te.getTime()-ts.getTime())/(60*1000);
		for(ParkingSlot p :station.getParkingSlots()) {
			time = time +p.calculateOccupationDuration(ts,te);
		}
		return (double)time/(station.getnSlots()*delta);
	}
	
	/**
	 * 
	 * this method getNumberRentsOperations
	 * @return the number of rents operations of our station
	 */
	
    public int getNumRentsOperations() {
    	numRentsOperations=0;
		for(ParkingSlot p :station.getParkingSlots()) {
			numRentsOperations+=p.getNumRents();
		}
		return numRentsOperations;
	}
   
    public int getNumReturnsOperations() {
		numReturnsOperations=0;
		for(ParkingSlot p :station.getParkingSlots()) {
			numReturnsOperations+=p.getNumReturns();
		}
		return numReturnsOperations;
	}


	public Timestamp getTs() {
		return ts;
	}


	public void setTs(Timestamp ts) {
		this.ts = ts;
	}


	public Timestamp getTe() {
		return te;
	}


	public void setTe(Timestamp te) {
		this.te = te;
	}


	public Station getStation() {
		return station;
	}


	public void setStation(Station station) {
		this.station = station;
	}



	public void setNumRentsOperations(int numRentsOperations) {
		this.numRentsOperations = numRentsOperations;
	}


	public void setNumReturnsOperations(int numReturnsOperations) {
		this.numReturnsOperations = numReturnsOperations;
	}


	public double getAverageRateOccupation() {
		return averageRateOccupation;
	}


	public void setAverageRateOccupation(double averageRateOccupation) {
		this.averageRateOccupation = averageRateOccupation;
	}


	@Override
	public String toString() {
		return "StationBalance [Station=" + station.getID() + ", numRentsOperations="
				+ numRentsOperations + ", numReturnsOperations=" + numReturnsOperations + ", averageRateOccupation="
				+ averageRateOccupation + "]";
	}

}
