package CostComputing;
import mainClasses.*;

/**
 * An interface that is used to compute the cost of a ride.
 * Implemented by cards of different types
 * @author Azzouz
 *
 */
public interface Visitor {
	/**
	 * Computes the cost of the ride for the mechanical bicycles.
	 * Sets the new time credit of the user's card if it's a Velib card
	 * @param bicycle: user's mechanical biycle
	 * @return cost of the ride
	 */
	public double visit(MechanicalBicycle bicycle);
	public double visit(ElectricalBicycle bicycle);

}
