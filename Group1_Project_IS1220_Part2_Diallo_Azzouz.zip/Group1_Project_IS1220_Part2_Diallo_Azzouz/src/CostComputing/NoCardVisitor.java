package CostComputing;

import mainClasses.*;

/**
 * The visitor of the credit card
 * Computes the cost of a ride for different types of bicycles.
 * @author Azzouz
 *
 */
public class NoCardVisitor implements Visitor{
	
	/**
	 * Computes the cost of a ride for the mechanical bicycles when the user does not have a Velib card.
	 */
	@Override
	public double visit(MechanicalBicycle bicycle) {
		double duration=bicycle.getBicycleUser().getRide().getDuration();
		return (duration/60)*1;
	}

	/**
	 * Computes the cost of a ride for the electrical bicycles when the user does not have a Velib card.
	 */
	@Override
	public double visit(ElectricalBicycle bicycle) {
		double duration=bicycle.getBicycleUser().getRide().getDuration();
		return (duration/60)*2;
	}

}
