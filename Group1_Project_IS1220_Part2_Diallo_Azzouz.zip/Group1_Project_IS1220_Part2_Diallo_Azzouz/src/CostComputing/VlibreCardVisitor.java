package CostComputing;

import mainClasses.*;

/**
 * The VLibre card visitor. 
 * Computes the cost of a ride for different types of bicycles.
 * @author Azzouz
 *
 */
public class VlibreCardVisitor implements Visitor{
	
	/**
	 * Computes the cost of a ride for the mechanical bicycles when the user's card is VLibre.
	 * Sets the new time credit of the user's card
	 */
	@Override
	public double visit(MechanicalBicycle bicycle) {
		
		Card card=bicycle.getBicycleUser().getCard();
		int timeCredit=card.getTimeCredit();
		double duration=bicycle.getBicycleUser().getRide().getDuration();
		
		if (duration>60) {
			if (timeCredit<duration-60) {
				card.setTimeCredit(0);
				return ((duration-60.0-timeCredit)/60)*1 ;
			}
			else {
				card.setTimeCredit((int)(timeCredit-(duration-60)));
				return 0.0;
			}
		}
		else {
			return 0.0;
		}
	}

	/**
	 * Computes the cost of a ride for the electrical bicycles when the user's card is VLibre.
	 * Sets the new time credit of the user's card
	 */
	@Override
	public double visit(ElectricalBicycle bicycle) {
		Card card=bicycle.getBicycleUser().getCard();
		int timeCredit=card.getTimeCredit();
		double duration=bicycle.getBicycleUser().getRide().getDuration();
		if (duration>60) {
			if (timeCredit<duration) {
				card.setTimeCredit(0);
				if (duration-timeCredit>60) {
					return 1+((duration-60-timeCredit)/60)*2;
				}
				else {
					return ((duration-timeCredit)/60)*1;
				}
			}
			else {
				card.setTimeCredit((int)(timeCredit-duration));
				return 0;
			}
		}
		else {
			if (timeCredit<duration) {
				card.setTimeCredit(0);
				return ((duration-timeCredit)/60)*1 ;
			}
			else {
				card.setTimeCredit((int)(timeCredit-duration));
				return 0;
			}
		}
	}

}
