package CostComputing;

/**
 * An interface that is used to compute the cost of a ride, 
 * Immplemented by bicycles of different types
 * @author Azzouz
 *
 */
public interface Visitable {
	public double accept(Visitor visitor);
}
