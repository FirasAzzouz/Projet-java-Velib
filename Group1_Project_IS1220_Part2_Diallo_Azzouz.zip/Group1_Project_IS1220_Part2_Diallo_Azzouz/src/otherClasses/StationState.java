package otherClasses;

public enum StationState {
	ON_SERVICE, OFFLINE

}
