package otherClasses;

public enum SlotState {
	OCCUPIED, FREE, OUT_OF_ORDER

}
