package otherClasses;

public enum BicycleType {
	ELECTRICAL, MECHANICAL

}
