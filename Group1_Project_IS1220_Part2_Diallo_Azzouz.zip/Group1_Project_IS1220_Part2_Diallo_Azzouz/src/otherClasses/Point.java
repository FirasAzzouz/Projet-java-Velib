package otherClasses;

import java.util.ArrayList;
import java.util.List;

import mainClasses.*;

/**
 * Represents a point on earth, determined by it's longitude and latitude.
 * Contains also a methods that compute the distance between two points, give the closest station to a point, and locate 
 * the stations which are not farther than a certain percentage of the distance to a closest station from a point.  
 * @author Diallo
 *
 */
public class Point {
	static double R=6371; //Earth radius in kilometers
	private double longitude; 
	private double latitude;
	/**
	 * A point is represented by its latitude and longitude
	 * @param latitude: the latitude of the point (between -90 and 90)
	 * @param longitude: the longitude of the point (between -180 and 180)
	 */
	public Point(double latitude, double longitude) {
		//super();
		this.longitude = (double)Math.round(longitude*1000)/1000;
		this.latitude = (double)Math.round(latitude*1000)/1000;
	}
	
    /**
     * Computes the distance between two points.
     * We assume that earth is a sphere. We convert the geographical coordinates to cartesian coordinates and then use the scalar
     * product to determine the absolute angle between the two points. We use afterwards the earth radius to get the distance on
     * the sphere between the two points.
     * @param a: Point 1
     * @param b: Point 2
     * @return the distance between two points
     */
	public  static double CalculateDistance(Point a, Point b) {
		
		double[] p1=computeCartesianCoordinates(a);
		double[] p2=computeCartesianCoordinates(b);
		
		double psi=Math.acos(p1[0]*p2[0]+p1[1]*p2[1]+p1[2]*p2[2]);
				
		return R*psi;
	}
	
	/**
	 * Computes the cartesian coordinates of a point given the geographical position, assuming that earth is a sphere. 
	 * The method gives reduced cartesian coordinates of the point because they will be used to compute the absolute angle using 
	 * the scalar product, so we don't need at this stage the earth radius.
	 * @param a: Point (latitude, longitude)
	 * @return Reduced cartesian coordinates of the point (cartesian coodinates divided by earth radius)
	 */
	public static double[] computeCartesianCoordinates(Point a) {
		
		double[] p=new double[3];
		
		double theta=(90-a.getLatitude())*(2*Math.PI/360);
		double phi=(a.getLongitude()+180)*(2*Math.PI/360);
		p[0]=Math.sin(theta)*Math.cos(phi);
		p[1]=Math.sin(theta)*Math.sin(phi);
		p[2]=Math.cos(theta);
		
		return p;
	}
	
	/**
	 * A static method that gives the closest station to a source point. It will be used by different classes in the package 
	 * RidePlanning so we chose to define it as static.
	 * We calculate the distance from the point to all the stations and choose the closest one which is on service and has at 
	 * least one available bicycle.
	 * @param a: Point (latitude, longitude)
	 * @param s: a list of the stations in the system
	 * @return the closest station to the specified point
	 */
    public static Station ClosestStationSourcePoint(Point a, ArrayList<Station> s, BicycleType bicycleType){
		double distance = Float.POSITIVE_INFINITY ;
		Station st = s.get(0);
		
		for (Station sa : s) {
			if ((Point.CalculateDistance(sa.getLocation(),a)<distance)&& (sa.getState()==StationState.ON_SERVICE)&&(sa.getNumBicycle(bicycleType)>0)){ 
				distance = (Point.CalculateDistance(sa.getLocation(),a));
				st = sa;
			}
		}
		return st;
	}
	
	/**
	 * A static method that gives the closest station to a destinationpoint. It will be used by different classes in the package 
	 * RidePlanning so we chose to define it as static.
	 * We calculate the distance from the point to all the stations and choose the closest one which is on service and has at least
	 * one free parking slot.
	 * @param a: destination Point (latitude, longitude)
	 * @param s: a list of the stations in the system
	 * @return the closest station to the specified point
	 */
    public static Station ClosestStationDestinationPoint(Point a, ArrayList<Station> s){
		double distance = Float.POSITIVE_INFINITY ;
		Station st = s.get(0);
		
		for (Station sa : s) {
			if ((Point.CalculateDistance(sa.getLocation(),a)<distance)&& (sa.getState()==StationState.ON_SERVICE)&&(sa.getFreeSlots()>0)){ 
				distance = (Point.CalculateDistance(sa.getLocation(),a));
				st = sa;
			}
		}
		return st;
	}
    
    /**
     * A static method that gives the closest stations to a source point p. The closest stations are defined as the stations that 
     * are not farther than a certain percentage of the distance to the closest station. 
     * We calculate the distance from the point p to the closest station using the method ClosestStation then we search for 
     * the closest stations (with at least one occupied parking slot) by comparing their distance to the point to the distance 
     * of the closest station, times the percentage.
     * We chose this method to be static because it will be used by classes in the package RidePlanning.
     * @param p: source point (latitude, longitude)
     * @param stations: list of the stations in the system
     * @param percentage: the percentage used in the search for the closest stations (should be higher than 100)
     * @return a list with the closest stations
     */
    public static List<Station> ClosestStationsSourcePoint(Point p, ArrayList<Station> stations, BicycleType bicycleType, int percentage ){
		List<Station> closestStations=new ArrayList<Station>();
		Station closestStation=Point.ClosestStationSourcePoint(p, stations, bicycleType);
		double closestStationDistance=Point.CalculateDistance(p, closestStation.getLocation());
		double stationDistance;
		for (Station st:stations) {
			stationDistance=Point.CalculateDistance(p, st.getLocation());
			if ((stationDistance<=percentage*closestStationDistance/100) && (st.getState()==StationState.ON_SERVICE) &&(st.getNumBicycle(bicycleType)>0)){
				closestStations.add(st);
			}
		}
		return closestStations;
	}
    
    /**
     * A static method that gives the closest stations to a destination point p. The closest stations are defined as the stations that 
     * are not farther than a certain percentage of the distance to the closest station. 
     * We calculate the distance from the point p to the closest station using the method ClosestStation then we search for 
     * the closest stations (with at least one free parking slot) by comparing their distance to the point to the distance 
     * of the closest station, times the percentage.
     * We chose this method to be static because it will be used by classes in the package RidePlanning.
     * @param p: destination point (latitude, longitude)
     * @param stations: list of the stations in the system
     * @param percentage: the percentage used in the search for the closest stations (should be higher than 100)
     * @return a list with the closest stations
     */
    public static List<Station> ClosestStationsDestinationPoint(Point p, ArrayList<Station> stations, int percentage ){
		List<Station> closestStations=new ArrayList<Station>();
		Station closestStation=Point.ClosestStationDestinationPoint(p, stations);
		double closestStationDistance=Point.CalculateDistance(p, closestStation.getLocation());
		double stationDistance;
		for (Station st:stations) {
			stationDistance=Point.CalculateDistance(p, st.getLocation());
			if ((stationDistance<=percentage*closestStationDistance/100) && (st.getState()==StationState.ON_SERVICE) && (st.getFreeSlots()>0)){
				closestStations.add(st);
			}
		}
		return closestStations;
	}


    public double getLongitude() {
		return longitude;
	}
	
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}



	public double getLatitude() {
		return latitude;
	}



	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	@Override
	public String toString() {
		return "Point [longitude=" + longitude + ", latitude=" + latitude + "]";
	}
    
    


}



