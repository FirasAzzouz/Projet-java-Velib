package otherClasses;

public enum StationType {
	PLUS, STANDARD

}
