package otherClasses;

public enum RideState {
	IN_PROGRESS, FINISHED

}
