package otherClasses;

public enum CardType {
	VMAX, VLIBRE, CREDIT

}
